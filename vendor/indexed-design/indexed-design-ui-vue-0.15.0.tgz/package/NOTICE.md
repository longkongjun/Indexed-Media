# Third-party adoption

`@indexed-design/ui-vue` depends on and directly re-exports **Ant Design Vue 4.2.6**, an MIT-licensed library maintained by the Ant Design Vue team. It is a Vue implementation, separately versioned from the React `antd` package. Its original package, notices and license remain in the dependency distribution.

- Source and license: https://github.com/vueComponent/ant-design-vue/tree/4.2.6
- MIT license: https://github.com/vueComponent/ant-design-vue/blob/4.2.6/LICENSE
- Ant Design reference baseline: https://github.com/ant-design/ant-design/tree/6.6.7

Indexed Design does not claim authorship of these adopted component implementations. Indexed additions are its theme mapping, brand contract, request-state composition, capability metadata and preview application. Ant Design provides coverage and interaction references; Indexed Design defines its own visual rules. No Ant Design 6 API parity or complete custom visual adaptation is asserted.

Version 0.2.0 also directly depends on **@ant-design/icons-vue 7.0.1**, the official Vue icon package maintained in `ant-design/ant-design-icons`, under MIT. Its distribution retains the original license. The named `./icons` entry re-exports it; Indexed Design does not claim to have drawn those icons. See https://github.com/ant-design/ant-design-icons/tree/master/packages/icons-vue .

The 0.8.0 preview and optional Listy recipe directly use **@tanstack/vue-virtual 3.13.48** (MIT, TanStack / Tanner Linsley), with **@tanstack/virtual-core 3.19.7**. They are additional recipe/application dependencies, not fabricated exports or dependencies of this formal UI package. Original source and licenses are retained in the npm distributions. Source repository: https://github.com/TanStack/virtual ; exact adopted adapter distribution: https://registry.npmjs.org/@tanstack/vue-virtual/-/vue-virtual-3.13.48.tgz .

The 0.9.0 preview and optional layout recipes directly use **@egjs/grid 1.18.0** (MIT, NAVER Corp.) and **reka-ui 2.11.0** (MIT, Reka UI contributors). They are declared additional application/recipe dependencies; this formal UI package does not re-export their Masonry or Splitter primitives. Original notices/licenses remain in their npm distributions. Official sources: https://github.com/naver/egjs-grid and https://github.com/unovue/reka-ui .
