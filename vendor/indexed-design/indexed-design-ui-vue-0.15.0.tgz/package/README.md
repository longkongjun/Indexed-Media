# @indexed-design/ui-vue

可供独立 Vue 3 项目接入的 TypeScript 组件包。**交互能力采用 Ant Design Vue 4.2.6；视觉使用 Indexed Design 的品牌、语义配色、字阶、形状与密度规则。** Ant Design 6.6.7 是覆盖范围与交互思路的参照，两个版本不能视为同一套 API。

本包具名导出上游组件及其类型，保持组件身份、props、slots、events、v-model 和实例方法，避免制造没有必要的包装层。新增 `IndexedThemeProvider`、`createIndexedTheme` 与 `RequestState`。无需依赖 MediaFlow、设计站、工作流文件或任何源码路径别名。

## 构建与接入

在仓库根安装依赖后构建并打包：

```sh
npm run build -w @indexed-design/ui-vue
npm pack -w @indexed-design/ui-vue
```

在另一个 Vue 项目中安装生成的 `indexed-design-ui-vue-0.15.0.tgz`。当前只提供本地包，尚未发布 npm：

```sh
npm install /path/to/indexed-design-ui-vue-0.15.0.tgz
```

```vue
<script setup lang="ts">
import { ref } from 'vue';
import { IndexedThemeProvider, Button, Input, RequestState, type RequestStateValue } from '@indexed-design/ui-vue';
import '@indexed-design/ui-vue/style.css';

const name = ref('');
const state = ref<RequestStateValue>({ kind: 'content' });
function save() { /* 宿主管理业务请求 */ }
</script>

<template>
  <IndexedThemeProvider mode="light">
    <RequestState :state="state" @retry="save">
      <Input v-model:value="name" aria-label="项目名称" />
      <Button type="primary" @click="save">保存</Button>
    </RequestState>
  </IndexedThemeProvider>
</template>
```

组件样式由成熟库的 CSS-in-JS 机制随组件生成。`style.css` 是本包必要的作用域样式；不强制加载会重置宿主页面的全局 reset。使用子路径导入样式可以让构建器保留 CSS 副作用。

## 公开能力与采用边界

`webComponentCatalog`提供**73个稳定预览入口**，逐项标注成熟采用、原生能力或Indexed组合。Ant Design Vue公开组件、子组件和props类型从包入口导入；Listy/Masonry/Splitter/Tabs recipe直接导入各自额外依赖，BorderBeam直接用原生CSS，它们都不是本包假导出；图标通过 `@indexed-design/ui-vue/icons` 具名导入；原生颜色输入直接使用 HTML，不提供虚构的 ColorPicker Vue 组件。目录的 `kind` 与 `publicApi` 区分原生能力、成熟采用与 Indexed 组合。

完整采用 API 请查 [4.2.6 源码](https://github.com/vueComponent/ant-design-vue/tree/4.2.6/components) 和 [Ant Design Vue 文档](https://www.antdv.com/components/overview/)。本包不提供全局自动注册插件，推荐按需导入。

0.15.0 新增 `@indexed-design/ui-vue/state-labels` 子入口，导出只读映射 `stateLabels`：键为 recipe 的稳定英文状态 ID，值为简体中文显示标签。字典单源于本包 `src/state-labels.json`，覆盖 `catalog/recipes/{web-vue,android,apple}.json` 三端去重状态的并集（628 项）；状态 ID 是 API、深链与 AI 数据的主键，本映射只服务显示，不改变任何 ID。消费方建议双写展示「中文（english-id）」，未命中键回退显示原英文 ID。仓库根 `node tools/check-state-labels.mjs` 校验字典与三端 recipes 并集一致（无缺失、无多余键、无空值）。

这些入口表示可运行的基本示例，并不等于全量自有外观完成、Ant Design 6 功能兼容或人工验收通过。完整覆盖状态以仓库 `catalog/ant-design-coverage.json` 为准：

- Ant Design 6 的完整 ColorPicker、Masonry、Splitter、Listy、BorderBeam 等能力没有因采用旧版本而自动获得。ColorPicker 目前只交付原生不透明 sRGB 输入的采用 recipe；不包含透明度、广色域、渐变、预设色板和 Ant ColorPicker API。
- Vue 的 List 保留上游 4.2.6 能力，并在预览中标注当前目录已弃用；不能冒充 Listy。
- 图标显式依赖官方 `@ant-design/icons-vue@7.0.1`，提供 `./icons` 导出；这不是一套重新绘制的自有品牌图标。
- 表格、日期、上传、树、弹层等复杂组件复用成熟交互，未完成逐子 API 对照及全部品牌外观专项设计；保留上游结构和部分形状是当前已知限制。
- 上传预览只选择本地文件，不包含网络、鉴权和存储服务。二维码不包含扫码/配对；通知不包含系统推送。
- 通过 Vue/Vite 构建和 jsdom 行为检查，不意味着 SSR、水合、真实浏览器全键盘、屏幕阅读器或人工外观已通过。

## 品牌与主题

`IndexedThemeProvider` 内含上游 ConfigProvider 和 App 上下文。`mode` 为 `light | dark`，默认显式浅色以避免服务端和客户端读取系统偏好不同。宿主可自行读取系统偏好并传值。

- 默认 `evergreenBrand` 使用共享 v2.0.0 语义色，主题还映射中性层级、16px 基础字阶、44px 默认控件高度、8/12px 形状和 120/240/400ms 动效。
- `cobaltBrand` 演示另一个品牌，使用相同组件和行为。**Cobalt 仅覆盖主色与圆角；中性色、状态色与字阶仍为 Evergreen 基线**，主色派生色（hover/active/选中底色）由采用库算法计算。自定义品牌必需结构为 `{ name, primaryLight, primaryDark }`，可提供 `borderRadius`、`label` 与浅暗 `tokens` 映射；完整中性与状态色也可在 `theme.token` 覆写。
- `theme` 接受上游 `ConfigProviderProps['theme']`，可调整 token、components 与算法。局部 `--id-*` CSS 变量从实际主题派生，不要求消费者加载仓库根 tokens 文件。
- 0.2.0 深化常用按钮、表单、卡片、菜单、标签、反馈、模态和表格的规则：有语义的 hover/active/disabled/error 色、清晰表头、44px 标准控件、克制阴影和16px对话框圆角。部分细节使用作用域 CSS 覆盖固定版本 `ant-*` 类名；升级采用库时必须重验这些选择器。弹层通过组件Token继承主题；0.10的常用浮层recipe显式使用公开局部容器API，让便携CSS变量/rem规则也继承，详见[常用Web一致性](docs/web-consistency.md)。
- 其他 attrs 传给 ConfigProvider，例如 `locale`、`direction`、`component-size`、`get-popup-container`、`csp`。上游仍生成 `ant-*` 类名，项目不能把类名当稳定公共 API。
- 对话框、消息和通知应在 Provider 子组件中通过 `App.useApp()` 取得上下文实例。导出的静态 `message` / `notification` / `Modal.confirm` 是上游能力，直接调用不会自动继承局部品牌。

```ts
import { createIndexedTheme, cobaltBrand } from '@indexed-design/ui-vue';
const theme = createIndexedTheme('dark', cobaltBrand, {
  token: { fontSize: 16, controlHeight: 48 },
  components: { Button: { borderRadius: 12 } },
});
```

便携的 `src/token-baseline.json` 是共享源的生成副本，包运行时无需访问仓库。更新共享 token 后执行 `node packages/ui-vue/tools/sync-tokens.mjs`；测试会检查副本是否与 `tokens/generated/semantic.json` 一致。

## 原生采用、图标与 AI 使用指南

0.5.0 提供 50 个常用组件的可直接使用 Vue SFC、使用规则、状态及适用边界，机器数据为 `catalog/recipes/web-vue.json`。本轮新增下拉命令、树选择、级联、评分、滑块、统计、时间轴、加载、标记与标签十个真实采用示例。代码从 `apps/vue-preview/src/recipes/*Recipe.vue` 同源生成，预览应用运行这些文件，禁止另写文档伪代码。原生能力足够时，recipe 直接采用它；无需为了覆盖表增加一层空包装。recipe `states` 的英文 ID 是机器主键；其简体中文显示标签统一来自 `src/state-labels.json`（覆盖三端 recipes 状态并集，经 `./state-labels` 子入口导出，见上文公开能力一节），保证不同入口译法不漂移。

```ts
import { SearchOutlined, CheckCircleOutlined } from '@indexed-design/ui-vue/icons';
```

图标继承字体大小与颜色。装饰图标传 `aria-hidden="true"`；只有图标的按钮在按钮上提供可访问名称。根入口的 `Icon` 用于宿主提供自有 SVG，官方图标使用具名子入口可保留按需打包。

颜色采用 recipe 使用 `<input type="color">` 的 value、input、change 和 disabled。虽然新浏览器可能支持更多色彩能力，本 recipe 为跨端可预测性约定不透明 sRGB 六位十六进制值，不启用 alpha/colorspace，也不复制系统选色面板。主题样式只作用于网页中的输入入口。

```sh
node packages/ui-vue/tools/build-recipes.mjs
node packages/ui-vue/tools/build-recipes.mjs --check
```

每个 recipe SFC 已包含所需导入和 `style.css`；在应用根部配置一次 IndexedThemeProvider。示例中的 `id-recipe-*` 是公开样式入口提供的布局辅助类，不依赖预览站私有 CSS。RequestState 的同源演示和包内指南独立保留，不冒充 Ant 目录的一项。

## 请求状态组合

`RequestState` 接收 `content / loading / empty / error / offline` 五态；loading、error、offline 可传 `stale: true`。默认槽放内容，empty 槽放无数据时的宿主操作，恢复按钮只发出 `retry`。默认 300ms 后显示加载提示；快速完成和卸载会清理计时器。旧内容保留时应用原生 `inert` 并降低透明度，正常内容恢复交互。`loadingDelay` 与所有显示文案可定制。

## 预览与验证

0.3.0 增加独立 `#/experience` 路由，展示既有七个语义字阶、200% 文字放大以及十种页面状态和可操作恢复流程。这不是额外的 Ant 目录项；公开角色数据、`id-type-*` 样式、RequestState 可选原生恢复槽及嵌入消息约定见随包交付的 [体验指南](docs/experience.md)。示例只保留非敏感演示备注；受保护内容和敏感输入按真实宿主会话/权限策略处理。

```sh
npm run typecheck -w @indexed-design/ui-vue
npm run test -w @indexed-design/ui-vue
npm run build -w @indexed-design/ui-vue
npm run test:consumer -w @indexed-design/ui-vue
npm run dev -w @indexed-design/vue-preview
```

独立预览应用从正式 `dist` 包和样式入口导入；因此首次运行和库源码更新后先构建库。外部消费检查把真实 npm tarball 安装到仓库外临时目录，检查公开声明、CSS、图标子入口、全部71个recipe 与体验 SFC 的独立类型，然后生产打包；它不使用源码别名或工作区软链接，依赖安装需要访问 npm registry，缓存也只写临时目录。组件行为检查覆盖加载/禁用阻止点击、输入双向绑定和 focus、受控开关、表格自定义单元格/排序、状态恢复与主题隔离；原生颜色输入、图标命名、作用域样式、recipe 同源、详情组件交互、体验恢复及消息来源检查单列。更多组件仍需按迭代补充专项验证。


## 常用输入与反馈采用说明

下面的锚点对应 `src/recipes/` 下的完整可运行示例。它们保留 Ant Design Vue 4.2.6 的 API；不是 Ant Design 6 全 API 的重新实现。主题规则补充数值字形、树选择/悬停、分段容器、日期入口和浮层字阶，当前支持evergreen、cobalt及violet/jade/wine/cocoa；旧片段使用两品牌仅演示注入，不代表支持列表仍限于两项。

### auto-complete

使用 `AutoComplete` 的受控值、options 与 select；建议之外的自由输入依然有效。示例只有本地数据，不包含远端检索与输入法专项验收。

### input-number

`InputNumber` 清空后的运行时值归一为未填写，不转为零；`stringMode` 保存超安全整数。数值范围和精度策略由业务负责，不能代替财务校验。

### date-picker

`DatePicker` 用 `value-format="YYYY-MM-DD"` 输出日历日期，清除可选值不产生错误。日期不是 UTC 时间戳；区间、业务日历及服务端时区由宿主定义。

### time-picker

`TimePicker` 输出 `HH:mm` 钟面时间并约束五分钟步长。它不会建立系统提醒，日期、时区、夏令时与通知调度另行处理。

### popconfirm

`Popconfirm` 只承载简短低风险确认；显式确认和取消都有本地结果并将焦点还给原生入口。复杂任务采用对话框，真实删除及权限不在示例中。

### message

在 Provider 内调用 `App.useApp().message`，用同 key 从 busy 更新完成，避免消息堆叠。忙碌按钮使用 loading / aria-busy 保持入口与焦点；不可操作的权限项单独 disabled。普通消息内容声明 status，离开示例销毁自己的持续消息。

### notification

4.2.6 的通知容器固定使用 alert，未提供 Ant Design 6 的 role 覆写；本例因此采用需要处理的失败通知。它提供显式恢复、关闭和回到入口；普通成功采用 status 消息。这里没有系统推送或导入服务。

### popover

`Popover` 用可聚焦原生按钮触发；补充说明可显式关闭或 Escape 返回入口。关键限制同时出现在主内容；它不是模态任务容器，也不做焦点陷阱。

### segmented

`Segmented` 在同一数据的列表和摘要之间切换，禁用项保持不可用。页面导航、数据请求和响应布局由宿主处理。

### tree

`Tree` 的层级选择受控，示例包括禁用节点和整体禁用/恢复。不包含远端懒加载、大树性能保证或权限服务；客户端禁用不是服务端授权。


## 0.5.0 常用选择与信息说明

下列方案直接使用 Ant Design Vue 4.2.6 的成熟组件，代码来自预览运行的完整 SFC。没有新增同名包装组件，也没有升级为 Ant Design 6 全 API 兼容。关键表单、表格、状态文字及常用控件使用共享 rem 字阶；按钮、输入、单选下拉和标签以最小高度及自然换行适应放大文字。默认挂到 body 的复杂弹层仍由上游数值 token 驱动，全部弹层/浏览器组合的字号与读屏验收没有因此完成。

### dropdown

`Dropdown`负责成熟定位/外部关闭；4.2.6的autofocus和Menu方向键实现不足，有限三项overlay直接用原生button，显式管理方向键/Home/End/Escape/Tab和禁用跳过。不是整个Menu库的修复。命令/Escape回有效入口，外部点击尊重新焦点；无剪贴板/导出/真实权限服务。

### tree-select

`TreeSelect` 选择稳定目标值，分组不可选、只读节点禁用。未选目标提交时有可见错误，清空不会隐式选择另一节点。没有真实移动、远端懒加载或权限服务。

### cascader

`Cascader` 保留逐级的分类值，不能把显示标签当稳定路径。可选分类清空后回到选择入口；未选择时清除按钮禁用。没有文件系统操作、远端加载或搜索服务。

### rate

0.12的评分入口是原生半分select，成熟Rate只作disabled/aria-hidden装饰，规避采用库多个星radio同时checked的语义缺口。草稿/确认、未评分0和可读总分明确，显式应用/撤销不发真实评价。

### slider

0.11有限清晰度范围直接用原生range+number，label/description精确关联，无私有手柄扩展；草稿/确认分离，空值不变零，越界或步长不符不夹断为成功，取消恢复确认值。权限disabled与busy不同，系统拖块外观由浏览器负责。

### statistic

`Statistic` 把数值、单位、来源与更新时点并列呈现。刷新保留上次确认值，busy 挡住重复操作；显式完成后回到更新入口。不包含服务端统计、倒计时或精度算法。

### timeline

`Timeline` 与 `TimelineItem` 说明已发生的步骤，失败和完成都有文字；恢复只补未完成的步骤，完成聚焦稳定结果标题。4.2.6 使用 pending 属性，Ant Design 6 已有新的 items 组织方式；两者不能混用。示例不是后台执行回执。

### spin

`Spin` 的装饰旋转延迟 300ms，aria-busy 与文字立即表达刷新。内容和非敏感备注保留，原生 inert 暂停旧内容编辑；完成后回到仍挂载的刷新按钮。无权限示例单独 disabled，不与 busy 混淆。原生 inert / 触控 / 读屏仍需在目标环境验收。

### badge

`Badge` 展示数量、零值与状态；按钮名称和可见说明同时表达未读数，重复的装饰计数隐藏于读屏树。没有真实订阅或系统推送；processing 动效尊重页面减少动效偏好。

### tag

`Tag` 的可移除入口使用有名称的原生按钮。删除标签不删除资料，入口消失后聚焦仍可用的恢复按钮；状态标签保留文字。不包含业务编辑、权限策略或破坏操作确认。

本轮专项行为检查运行真实 SFC；`node packages/ui-vue/tests/browser-foundations.mjs` 直接消费正式预览构建，检查八类关键文字的真实 200% 字号、Cobalt 暗色评分及状态替换后的焦点。它不采集画面，也不替代人工外观、完整辅助技术或真实设备验收。


## 0.6.0 交互实验

本轮保持50条组件采用方案，新增七条可操作的推荐/问题对照预览。完整 `InteractionLab.vue` 使用正式包、成熟Modal与原生控件；它不是包导出。独立入口 `#/interactions?rule=state-ownership`，嵌入 `?embed=interactions#/interactions?rule=state-ownership`，本地品牌/明暗独立保留。操作、协议、字阶、未知回执及验证边界见随包交付的[交互实验指南](docs/interactions.md)。


## 0.7.0 排版、布局与上下文

新增八份完整 SFC，合计58条同源采用方案。它们直接采用成熟组件，附自己的语义字阶与品牌样式，不增加同名包装层。[版本差异与源码依据](docs/layout-foundations.md)记录真实采用版本与验证边界。

### typography

`TypographyTitle` 的 level 管理文档结构，视觉字号采用 Indexed 语义角色；标题可编辑、长正文自然换行。辅助文字不承载唯一错误或重要状态。不包含富文本编辑或 Ant 6 完整 Typography API。

### divider

`Divider` 组织分区，独立按钮展开补充内容。Vue4.2.6 的 orientation 为标题位置，不能复制 Ant6 的方向参数；分隔线不替代语义标题或错误信息。

### flex

`Flex` 用数值 gap、wrap 与 vertical 切换方向。320px只是容器宽度，不能冒充视口断点；保持DOM与键盘顺序。采用版本不把任意字符串 gap 当CSS长度。

### grid

`Row`/`Col` 使用真实视口 xs/md/lg 断点，动态卡片保持稳定key。卡片自然增高；画布宽度切换不意味着浏览器媒体查询已改变。数值gutter沿用采用版本。

### layout

`LayoutSider` 在真实窄窗收起，隐藏侧栏设 inert 与 aria-hidden，侧栏中原有焦点交给稳定展开入口。页头没有锁定文字高度，本地分区不等于产品路由或服务端权限。

### space

`Space` 的 direction/size/wrap 只管理间距，真实操作、disabled 与结果独立表达。采用Vue4.2.6 direction API；不照搬Ant6新orientation/vertical参数。

### anchor

`Anchor` 呈现目录并追踪正文滚动；宿主捕获已知目录链接的click，取消默认hash变更及上游无条件平滑滚动，立即移动正文和标题焦点。标题使用tabindex=-1，Enter与点击走同一链；此适配依赖采用版本DOM事件结构，升级须复验。不包含外部链接或完整路由器。

### app

`App.useApp()` 必须在App后代中调用，等容器ref就绪后挂App，通过Provider公开getPopupContainer把消息挂在自己的主题DOM内，用同key更新并在子组件卸载时只销毁本例key。局部Evergreen/Cobalt与明暗切换影响动态消息；普通完成用status。它不是系统通知、真实事务或Ant6全部App能力。


## 0.8.0 虚拟列表与常用展示

新增8份同源SFC，合计66条。Listy是直接采用公开TanStack虚拟化能力的使用方案，不是新增正式包导出；其他7项采用现有Ant Design Vue 4.2.6。依赖、固定源码、字体和API边界见[集合与导航说明](docs/collections.md)。

### listy

额外安装 `@tanstack/vue-virtual@3.13.48`，完整SFC直接导入 `useVirtualizer`，不从本UI包导入Listy。1000条合成记录按可见窗口及overscan实际挂载；稳定key来自ID，ResizeObserver/measureElement测动态高度，scrollToIndex定位远处条目。局部刷新失败保留列表与选择；删除当前条目或滚动卸载焦点行时回到列表入口。没有分组/吸顶/无限请求或Ant Listy全部API。

### float-button

采用有可访问名称的FloatButton，局部absolute位置不抢占全局导航，操作结果有文字。真实应用需规划全局固定位置和安全区；没有宣称BackTop/分组完整适配。

### carousel

显式前后按钮和序号，不自动播放，速度0且使用公开goTo无动画。到达边界后将焦点移交仍有效的反向入口；文本自然增高。没有视频或远端播放逻辑。

### affix

等滚动容器ref就绪再挂Affix，公开target/offsetTop控制实际固定位置。固定入口仍可用键盘操作；复杂transform祖先及嵌套滚动未全量适配。

### qr-code

采用成熟SVG二维码，配非凭据合成payload、文字说明和显式失效/再生操作；失效后焦点交给再生入口。二维码保持深色前景/白色背景的独立高对比区域，不为品牌牺牲可扫性。未做相机扫描率、登录协议或真实标记撤销验收。

### calendar

采用成熟七列日历，valueFormat输出日期字符串，放大后保留局部横向滚动。日期不等于UTC时间戳，不创建系统日程。目标读屏、业务日历与时区另行验证。

### transfer

成熟Transfer公开children配原生搜索/多选框；临时勾选、目标草稿、已确认集合分开。移动只改草稿、应用/撤销明确，空目标局部错误保留确认集合；禁用与权限回调guard，搜索空态可清除。没有真实移动/授权服务。

### mentions

成熟Mentions保留有标签textarea、键盘建议与权限锁定；不可用组显式排除候选，避免采用版本options.disabled的键盘缺口。字段失败保留备注并定位回输入，普通完成status；只模拟本地确认，不会发送消息。复杂IME、读屏及远端成员搜索尚未验收。


## 0.9.0 特殊布局与装饰

补充Masonry、Splitter、BorderBeam三份完整SFC，当时合计69份；并完善Tooltip的focus/Escape/长文语义。直接采用公开成熟能力或原生CSS，不为名称新增空壳导出。[来源、API与适配边界](docs/special-layout.md)随正式包交付。

### masonry

额外安装 `@egjs/grid@1.18.0`，完整SFC直接调用公开MasonryGrid JS引擎。测量真实高度、放入最短列并监测尺寸变化，保留Vue稳定ID与DOM/Tab顺序；提供同一DOM的单列阅读模式。追加/移除后syncElements，卸载destroy清理；不是静态columns、虚拟列表或ui-vue.Masonry导出。

### splitter

额外安装 `reka-ui@2.11.0`，使用其公开SplitterGroup/Panel/ResizeHandle。分隔条支持原生指针、方向键和Home/End，最小比例25%。窄于42rem后同一面板上下阅读、分隔条隐藏并禁用；原焦点在条上时交给稳定标题，非敏感备注保持。没有折叠、嵌套或比例持久化；不是ui-vue.Splitter导出。

### border-beam

直接采用CSS遮罩和运动路径，纯装饰aria-hidden、pointer-events:none。实际系统prefers-reduced-motion及forced-colors停止装饰，本地暂停不会覆盖系统偏好；不支持相关CSS时保留静态边框。键盘焦点描边与业务状态单独呈现，没有正式BorderBeam包导出。

Tooltip的关键限制始终在正文；补充说明通过aria-describedby关联，focus/hover都可打开，Escape关闭后焦点留在原入口。浮层继承局部主题和rem字阶，长路径换行，不能把交互按钮放进仅补充说明的Tooltip。以上方案均不代表Ant6全API或全部读屏/设备验收完成。


## 0.10.0 常用交互深化

Modal、Drawer、Popconfirm、Message、Notification、Dropdown/Menu、Tabs、Form、Input、Select十份既有SFC补齐局部浮层主题/rem、真实错误恢复、草稿与关闭后回调失效、稳定名称及有效/失效入口焦点。没有新增组件或依赖，69份recipe保持原ID。可直接复制的API和宿主职责见[常用Web一致性指南](docs/web-consistency.md)；业务unknown回执不能套用本地可取消校验。

### modal

可取消的本地名称校验使用固定名称、即时busy guard、独立结果交付和owner时效检查；关闭保留非敏感草稿，晚到回调无效，失效入口回稳定标题。真实写请求结果未知需权威核对。

### drawer

宿主持有非敏感草稿，Escape/明确关闭返回有效入口，入口移除则回标题。公开局部getContainer使正文rem和长文本自然重排。

### form

公共失败事件生成错误摘要并聚焦首错，显式help ID关联错误文字；保留字段值、忽略outOfDate校验结果，修改后重新提交。无真实保存服务。

### input

错误字段可真实编辑恢复；帮助文字关联输入。本地重复值规则不能替代真实服务端唯一性校验。

### select

必选字段原生select精确关联错误并定位，补值恢复、其他成熟Select选择保留。4.2.6不会透传ARIA错误帮助到内部combobox，故不伪称完成；有限三项成熟弹层关闭虚拟化，以rem自然增高。

### tabs

额外精确依赖reka-ui2.11.0公开TabsRoot/List/Trigger/Content，manual激活：方向键/Home/End移焦，Enter/Space激活，跳过禁用标签；宿主持有非敏感备注。采用库ADV4.2.6的Tabs未实现完整方向键，本例不导入该Tabs、不新造包装。页面导航与动态删除标签不在范围。


## 0.11.0 选择、引导与显示

四份日期/数值SFC深化，Tour/Watermark补成完整同源采用方案，共71份；预览73入口、依赖版本均保持。公开API、原生字段/成熟组件边界、日期/墙上时刻及字阶说明见[选择与引导指南](docs/selection-and-guidance.md)。

### tour

直接采用公开Modal组织可跳过的两步说明，复用焦点陷阱、Escape与局部rem，不造锚定Tour。步骤变化聚焦标题，完成不提交业务，关闭保稿并回有效入口或备用标题。

### watermark

成熟Canvas水印只作合成署名装饰，aria-hidden/pointer-events隔离，正文提供等价文字。可显式应用/撤销署名或隐藏装饰；字号由本地实际rem换算数值传入。不能防截图/复制或替代鉴权。


## 0.12.0 草稿选择深化

Mentions、Transfer、ColorPicker、Rate、Upload、Listy六份既有方案深化，仍71条ID与73预览入口，依赖不升级。草稿、确认、局部错误、权限和200%可读选值一致；实际采用限制及来源见[草稿选择指南](docs/draft-selection.md)。

### upload

有限本地清单直接采用原生file，逐项检查演示类型/大小/数量，同名独立ID、拒绝保留旧草稿，显式确认/撤销元数据。accept不是安全验证，不读取内容、不上传或伪造成功回执。

## 0.13.0 容器布局与焦点

保持71份同源方案、73预览入口与现有依赖版本。Masonry增加真实说明展开测高、稳定ID详情、只读修改guard和失效入口焦点；Splitter直接采用Reka公开折叠/展开并补权限键盘守卫；Layout改按实际容器和rem阈值重排，同一导航/选择保持。完整代码随方案复制，不增加同名包装导出。采用方式、额外精确依赖和限制见[特殊布局](docs/special-layout.md)。

## 0.14.0 导航与中断恢复

保持71份方案/73入口，依赖不升级。少量资料分区改用原生nav/details/summary/button，提供真实Tab/Enter/Space/Escape、当前位置与撤权焦点；正式Menu成熟导出身份不变。Splitter在在途手势被中断时重建公开Group，宿主持有草稿/比例并提供键盘恢复，正常布局仍同DOM。完整采用与系统输入限制见[导航与布局中断](docs/navigation-and-interruptions.md)。

## 0.15.0 弹层容器与rem一致性

保持71份同源方案、73预览入口与现有依赖。AutoComplete、Cascader、TreeSelect、Popover与头像成员Tooltip补齐region+getPopupContainer样板，弹层不再落在body、能继承`--id-*`变量与rem规则；日历头部年份/月份选择由组件自身挂在头部节点内。Provider的自定义数值fontSize改以rem写入`--id-font-size-base`，并新增导出`--id-icon-size-sm/md/lg`（图标示例随之token化）。Popover Escape补齐stop/prevent，Cascader清除后经组件ref回焦；Progress增加总量未知时的Spin不定加载演示。预览外壳字号全部归入id-type-*/`--id-font-size-*`角色。容器样板、数值间距换算与Cobalt覆盖边界见[常用Web一致性](docs/web-consistency.md)。

### 支持的品牌配色

`indexedBrands`提供`violet`暮紫银雾、`jade`墨青玉灰、`wine`酒红陶玫、`cocoa`可可砂岩，以及原有`evergreen`与`cobalt`。例如：

```vue
<script setup>
import { IndexedThemeProvider, indexedBrands, Button } from '@indexed-design/ui-vue';
</script>
<template>
  <IndexedThemeProvider mode="dark" :brand="indexedBrands.violet">
    <Button type="primary">继续</Button>
  </IndexedThemeProvider>
</template>
```

四套主题的浅暗语义值来自共享Token，不只替换主色。错误/成功/警告等语义色沿用现有值，宿主传入theme覆盖仍生效。默认品牌保持evergreen；原生端已实现同源主题映射，平台与设备验收单列。品牌渐变不是按钮默认背景。


## 品牌符号与实际场景

正式导出`IndexedBrandMark`、`IndexedBrandLockup`、`IndexedSymbol`、`IndexedBrandLayout`和`IndexedBrandVariant`。符号包括indexed/media/read/music/tv/photos/console/learn，组合支持standard/compact/endorsed及horizontal/vertical。`name`可传实际产品名MediaFlow；默认家族英文名不代表正式产品命名。细节见[跨端品牌组件](../../docs/brand-components.md)。

```vue
<script setup lang="ts">
import { IndexedThemeProvider, IndexedBrandLockup, indexedBrands } from '@indexed-design/ui-vue';
import '@indexed-design/ui-vue/style.css';
</script>
<template>
  <IndexedThemeProvider mode="light" :brand="indexedBrands.jade">
    <IndexedBrandLockup symbol="media" name="MediaFlow" variant="compact" />
  </IndexedThemeProvider>
</template>
```

独立图形使用`IndexedBrandMark`的`label`提供名称，图文相邻时隐藏重复图形语义。应用自身用主标＋Indexed Design；`#/brand`中的导航、连接/登录、关于、七业务选择真实消费正式组件，演示状态只在本地修改。TV符号表示直播业务，MediaFlow电视客户端仍用media。品牌背景、状态动效和正式产品接入未包含在本轮。

统一规则与来源在[foundations/brand.json](../../foundations/brand.json)，构建生成`api/v1/brand.json`/`.md`，包含六端API、规则、示例源和内容指纹；不计入Ant组件覆盖分母。
