# 常用Web交互与局部主题

0.10.0深化既有69份中的10份消费者SFC，没有增加组件包装或升级依赖。代码仍直接使用Ant Design Vue 4.2.6公开API，视觉采用Evergreen/Cobalt语义色、rem字阶和自然增高的控件；Cobalt仅覆盖主色与圆角，中性色、状态色与字阶仍为Evergreen基线。完整同源代码在预览的“可直接使用的Vue示例”与catalog/recipes/web-vue.json；复制后在应用根使用IndexedThemeProvider并加载style.css。0.15.0把入口类弹层的region容器样板补齐到AutoComplete/Cascader/TreeSelect/Popover/头像Tooltip，并把自定义fontSize承诺锁在rem单位。

## 浮层的所有权与样式

Vue组件上下文继承与DOM CSS变量继承是两件事。默认body浮层可以获得ConfigProvider的数值token，却不在局部.id-theme DOM之内；它不会自动继承本包rem规则。Modal/Drawer用公开getContainer，Popconfirm/Dropdown/Select/AutoComplete/Cascader/TreeSelect/Popover/Tooltip（含头像成员提示）用getPopupContainer返回本例region；位置仍由成熟组件计算。Message/Notification使用本例ConfigProvider的getPopupContainer，等region ref就绪后才挂局部App，再在App后代调用App.useApp。不要在App挂载后才更换首次缓存的容器，也不要把静态message/notification调用当成局部App实例。

### 可复制样板：region + container()

入口类弹层统一使用同一容器样板，让弹层挂进所属示例/页面区域而不是body，才能继承`.id-theme`的`--id-*`变量与rem规则：

```vue
<script setup lang="ts">
import { ref } from "vue";
const region = ref<HTMLElement>();
function container() { return region.value ?? document.body; }
</script>
<template>
  <section ref="region" class="id-recipe-stack">
    <!-- Select / AutoComplete / Cascader / TreeSelect / Dropdown：:get-popup-container="container" -->
    <!-- Popover / Popconfirm / Tooltip：:get-popup-container="container" -->
    <!-- Modal / Drawer：:get-container="container" -->
  </section>
</template>
```

`document.body`只是region ref未就绪时的兜底；正常渲染路径必须已经进入region。日历头部年份/月份Select由Calendar自身挂在其头部节点内，天然位于`.id-theme`之内，宿主无需再传容器。

有限数值间距（Space的size、Row/Col的gutter等数值）为16px根字号下的space token换算：8=space-2（0.5rem）、16=space-4（1rem）、24=space-6（1.5rem）；采用库吃数值，宿主传入等价数值而不是rem字符串，样式层则直接使用rem值或`--id-*`变量。

CSS只在.id-theme内适配固定版本的ant-*类名：正文16px参考值对应1rem、标题20px对应1.25rem、按钮最小高度、长文换行、模态正文内部滚动以及反馈宽度约束。body之外其他门户、额外嵌套滚动/transform祖先仍须按宿主验证；日期/树等复杂弹层已随上述入口容器样板挂进region，不再落回body，transform祖先内的定位仍按宿主验证。有限三个Select选项关闭虚拟化，行高能自然测量；不要把这一配置当作海量数据性能方案。升级采用库必须重验选择器。

## 10份示例的明确行为

| 示例 | 所有权与恢复 |
| --- | --- |
| Modal | 可取消的**本地名称校验**使用即时busy guard、固定名称和aria-busy/aria-disabled；入口原生disabled保持false。独立动作交付Promise结果，关闭/卸载使owner失效；晚到结果不改新会话，失败保留草稿。afterClose只回仍连接且可用的入口，否则回稳定标题。 |
| Drawer | 宿主持有非敏感说明草稿；Escape或明确关闭保留值。afterOpenChange只在已关闭且仍挂载时归还焦点，入口移除则回标题。 |
| Popconfirm | 对象明确为临时筛选，取消保留；确认后原入口disabled，使用标题备用焦点。Escape由局部键盘捕获处理。4.2.6沿用tooltip容器，**没有完整alertdialog语义/焦点陷阱承诺**；高风险或复杂任务用Modal。 |
| Message | 同key从loading更新成功/失败，普通反馈status、失败alert。名称始终“保存演示设置”，即时guard阻止重复；非敏感备注busy只读，失败后可重试，独立完成动作归还焦点。卸载只销毁自己的key。 |
| Notification | 4.2.6容器固定alert，故只演示需处理失败。明确恢复与关闭，回有效入口或稳定标题；owner/卸载检查防止抢新页面焦点。不用于普通成功播报。 |
| Dropdown/Menu | 4.2.6虽声明autofocus但vc-dropdown未消费，Menu仅处理Enter而无完整方向键。因此成熟Dropdown保留定位/外部关闭，有限三项overlay直接用原生button，显式方向键/Home/End/Escape/Tab及禁用项跳过。不是修复整个Menu库；多级/类型检索另行处理。 |
| Tabs | ADV4.2.6的Tabs仅支持Enter/Space激活，方向键没有实现；本例改直接采用已存在的reka-ui2.11.0公开TabsRoot/List/Trigger/Content。manual模式明确方向键/Home/End移焦，Enter/Space激活，成熟原语跳过disabled；宿主持有非敏感备注，unmountOnHide=false保留隐藏面板DOM。不从ui-vue导入假造的Reka组件。 |
| Form | 公共onFinishFailed生成可操作错误摘要并聚焦首错；各字段显式help ID与aria-describedby相连，公开help空数组抑制采用库默认自动错误列表，宿主字段帮助不再重复声明alert，摘要为唯一可见alert。忽略outOfDate结果，保留已填写值；提示为上次提交结果，修改后重新提交。 |
| Input | 错误字段受控可编辑；非空且不同于初始合成重复值即可恢复，文字说明始终在正文。它不验证真实唯一性；演示口令不请求/存储。 |
| Select | 必选错误字段直接采用原生select，精确关联aria-invalid/aria-describedby；确认后聚焦、补值恢复且其他分类保留，不自动代选。ADV有限三项关闭虚拟化只改善可见行的自然增高，内部仍有隐藏ARIA代理列表，并未把错误描述透传内部combobox；不声明这些语义缺口已修复。原生选项面板由浏览器绘制。 |

本地合成失败不代表业务请求的最终失败。**真实写请求在中断后结果未知时，必须保留unknown回执并由宿主权威核对，不能根据本例Modal的可取消本地校验自动重发。** 草稿保留仅指普通非敏感输入；权限变化后受保护内容、凭据及敏感输入按宿主会话策略隐藏/清理。局部busy不等于权限不可用；后者使用disabled与可见原因，服务端仍负责授权。

## 实际采用与参考边界

运行采用版本：ant-design-vue@4.2.6。核对本机安装的es/modal/Modal.js、es/drawer/index.js、es/popconfirm/index.js、es/dropdown/props.js、es/dropdown/dropdown.js、es/vc-dropdown/Dropdown.js、es/menu/src/Menu.js、es/menu/src/MenuItem.js、es/notification/useNotification.js、es/form/FormItem.js、es/form/FormItemInput.js、es/form/ErrorList.js、es/form/Form.d.ts、es/form/interface.d.ts、es/vc-select/Selector/Input.js和es/vc-select/BaseSelect.js、es/vc-select/OptionList.js、es/tabs/src/TabNavList/index.js与TabNode.js。vc-select文件仅用于核实公开Select的ARIA透传行为，**示例没有导入任何私有vc-*模块**。

覆盖/交互参考为[Ant Design固定revision dc3a92dcf2fd4d707418c2288901ecc86f26f647](https://github.com/ant-design/ant-design/tree/dc3a92dcf2fd4d707418c2288901ecc86f26f647)。本轮按容器、焦点、失败回调和disabled相关段落实际阅读：

- components/modal/Modal.tsx、components/drawer/Drawer.tsx、components/popconfirm/index.tsx
- components/message/useMessage.tsx、components/notification/useNotification.tsx
- components/dropdown/dropdown.tsx、components/tabs/index.tsx、components/form/Form.tsx、components/input/Input.tsx、components/select/index.tsx、components/menu/index.tsx
- components/modal/__tests__/Modal.test.tsx、components/drawer/__tests__/DrawerEvent.test.tsx、components/popconfirm/__tests__/index.test.tsx、components/message/__tests__/hooks.test.tsx、components/dropdown/__tests__/index.test.tsx、components/form/__tests__/index.test.tsx
- components/modal/index.en-US.md、components/drawer/index.en-US.md、components/message/index.en-US.md、components/notification/index.en-US.md、components/dropdown/index.en-US.md、components/tabs/index.en-US.md、components/form/index.en-US.md、components/select/index.en-US.md中的相关API段落。

这是源码/测试组织对照，并未运行上游React测试；Ant6的focusable/destroyOnHidden/语义classNames等新API不能抄给Vue4.2.6。Vue示例使用该采用版本实际公开API，不复制Ant默认配色/站点外观。

额外Tabs采用源为[Reka UI官方Tabs文档](https://reka-ui.com/docs/components/tabs)及实际安装的reka-ui@2.11.0/src/Tabs/{TabsRoot,TabsList,TabsTrigger,TabsContent}.vue，核对modelValue、manual激活、disabled、ARIA关联与unmountOnHide。样式由本包提供，未复制第三方皮肤；未新增或升级依赖。

## 验证边界

定向unit核验本地owner失效、错误恢复与草稿，真实Chromium核验10个场景的DOM、键盘、焦点与计算样式，200%通过修改文档根字号实现，未与实验页独立文字缩放叠加。正式tarball外部安装后全部71个SFC、ExperienceFoundations和InteractionLab独立类型检查及生产打包。没有截图、视频、trace，也没有宣称全读屏、全部触控设备、跨浏览器或所有弹层完成验收。
