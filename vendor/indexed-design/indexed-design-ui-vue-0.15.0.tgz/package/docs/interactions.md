# Web 交互实验

0.6.0 不增加组件目录数量。`apps/vue-preview/src/InteractionLab.vue` 是使用正式包与原生 HTML 的完整预览场景，不是 `@indexed-design/ui-vue` 的伪造导出；宿主可复制完整 SFC 使用。共享七条规则与各平台映射由根体验规范提供，这里交付实际操作与局部问题对照。

## 入口与协议

- 独立应用：`#/interactions?rule=state-ownership`。
- 专用嵌入：`components/vue/?embed=interactions#/interactions?rule=focus-return`，没有应用侧栏、wordmark 或重复规则导航。
- 保留本地品牌与明暗原生控件；查询参数 `brand=cobalt`、`theme=dark` 可设初始值。Vue Cobalt 不等同于根工作台的其他品牌。
- 七个稳定 ID：state-ownership、error-scope、focus-return、feedback-copy、text-and-layout、motion-preference、destructive-action。

父页发送 `{type:'indexed-interaction-rule', rule:'error-scope'}`，子页回传 `{type:'indexed-interaction-rule-changed', rule:'error-scope'}`。只接受同 origin、来源为 window.parent、类型及 ID 均合法的消息。父页也应核对 origin 与具体 iframe.contentWindow。挂载时只规范化 hash，不发送默认 ID 覆盖父状态；顶层不向自身回传，避免回环。规则切换保持实验实例，关闭旧弹层；没有跨刷新持久化。

## 可操作对照

| 规则 | 推荐操作与可见结果 | 问题对照 |
|---|---|---|
| state-ownership | 保存名称和焦点保留，busy 阻止重复，独立完成动作；权限按钮单独 disabled | 模糊名称且重复点击继续增加计数 |
| error-scope | 字段错误、摘要链接与首错定位；已填值和其他内容保留 | 局部字段错误替换整个区域，失去修改入口 |
| focus-return | 成熟 Modal 取消返回入口；模拟入口删除后定位备用标题 | 入口删除且没有替代目标 |
| feedback-copy | 图形、具体状态、保留情况与本地恢复动作；备注保留 | 只用颜色表达结果 |
| text-and-layout | 100%/200%、长文与320/560 CSS px容器；文字/按钮自然伸展 | 明确标示的固定高度与 nowrap 裁切 |
| motion-preference | 读取真实 matchMedia，并响应系统变化；按操作仅播放一次短位移 | 普通模式较长位移；reduce 下问题例也冻结，避免强迫不适 |
| destructive-action | 具体对象/取消/处理状态；unknown 关闭重开仍保留，权威未执行且重审后才能再次确认 | 模糊“确定”直接显示不清楚的完成结果 |

所有示例都是页面内合成状态，无真实服务、权限变更、凭据或文件副作用。顶端重置只重置当前规则的本地演示；不能据此清除真实系统未知请求的事实。

## 正式 Button 与 Lab 原生按钮的对应

正式包直接导出 Ant Design Vue 4.2.6 的 `Button`。核对当前安装的 `es/button/button.js`：`loading: true` 仅更新加载图标和 `innerLoading`，不会自行给原生 `<button>` 添加 disabled 或移除 tabindex；`handleClick` 在 innerLoading 或明确禁用时阻止默认动作并停止向宿主发出 click。因此，未被显式 disabled / 禁用上下文覆盖的普通按钮在加载时仍保留 DOM 入口和原生焦点能力；真实权限禁用仍使用 disabled。`href` 分支输出链接，不作为本指南的提交按钮示例。

Lab 使用原生 button 把同一契约展开：保留“保存设置”名称，传 aria-busy / aria-disabled，宿主 busy guard 阻止重复，完成时回到有效入口。正式 Button 可直接采用 `:loading="busy" :aria-busy="busy" :aria-disabled="busy"`；默认槽保持“保存设置”，并显式设置 `aria-label="保存设置"`，避免采用库加载图标的“loading”标签改变可访问名称；不要用忙碌状态替换操作名称。上游会透传这些 ARIA 属性，但不自动生成它们，任务状态、文案、完成与恢复仍由宿主持有。

宿主处理函数仍应立即检查 `if (busy) return`，再设置 busy。特别是 `:loading="{ delay: 300 }"` 会延后 innerLoading 生效，不能把视觉延迟当作请求互斥；同一更新帧和视觉延迟内也必须由业务 guard 防重。不要为了延迟旋转而延迟真实 busy 状态。基本 Button recipe 与 Lab 使用相同推荐契约：固定“保存设置”名称、即时 busy guard、loading 与 ARIA；独立的本地完成或失败动作给出结果并回到该入口。失败不会被显示成成功，也不执行真实请求。

## 稳定检查入口

根节点 `[data-interaction-rule]` 标示当前规则。每项有 `[data-comparison="recommended"]` 和 `[data-comparison="problem"]`；操作使用 `data-action`，结果使用 `data-result`。例如 ownership-save / ownership-finish、error-submit / error-first、focus-open / focus-remove-entry / focus-cancel、feedback-state / feedback-retry、layout-scale / layout-long / layout-width、motion-run、danger-open / danger-confirm / danger-resolve / danger-query / danger-review。

危险演示的本地结果和权威回执选择器显式标为模拟。unknown 没有再次确认入口；确认未执行后仍需显式重新核对。busy 不能取消已发送请求，但明确显示如何完成本地模拟。完成/关闭的焦点由成熟 Modal 的 afterClose 属性回调定位，规则已切换时不抢新任务焦点。

## 字阶、动效与验证边界

页面直接使用公开七角色及已有 rem token；默认根字号16 CSS px时正文1rem约16px，原生使用系统语义字号/缩放，详细映射由共享规范提供。200%按钮只控制布局对照内的文字，浏览器缩放和系统字号仍需另外验收。

`tests/interactions.test.ts` 检查状态与公开回调契约；jsdom 不提供真实 CSS leave 完成，因此实际 Modal 关闭生命周期、焦点、字号/重排、matchMedia 与父子消息另由 `tests/browser-interactions.mjs` 在正式预览构建上验证。检查不采画面，不替代读屏、IME、原生设备或人工外观验收。
