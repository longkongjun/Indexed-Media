# 导航与布局中断

0.14.0保持71份同源方案、73个预览入口和现有依赖。只深化Menu与Splitter，正式Menu仍是Ant Design Vue4.2.6成熟导出；原生导航recipe不是新包装，不代表修复整个成熟Menu。提及/瀑布流仍按既有边界直接采用，并对照共享组合规范。

## 少量分区使用原生导航

旧Menu recipe在根字号200%时仍显示16px，实际ArrowDown不移动入口焦点。安装包MenuItem.js只有Enter选择路径，不能把它当作完整方向键菜单。此例需要的是少量资料分区，因此直接采用nav、details/summary和button：Tab进入入口、浏览器原生Enter/Space展开/激活，Escape只关闭展开的工作空间并回summary。没有role=menu/menubar，不伪造箭头键或roving tabindex。details只折叠导航分组的额外控件，不充当ARIA菜单，遵循[HTML公开语义](https://html.spec.whatwg.org/multipage/interactive-elements.html#the-details-element)。

当前分区用aria-current和“当前位置”文字共同标识。稳定ID与显示名称分开；重复选择当前分区不重复emit。撤回成员分区后清除该本地选择，回资料库并聚焦有效入口；native disabled与navigate回调都核对当前可用性。样例只切合成内容，不存储受保护内容，不替代真实路由、成员授权或服务器判断。实际导航应使用有效href或宿主router，本例无URL/返回历史。长标签使用现有rem和自己的品牌边框，自然增高，不以裁切换取固定高度。

## 在途手势被中断

Reka2.11.0的handle.disabled会注销resize注册；拖拽中切只读后，旧Group可能没有收到结束回调，Panel留下pointer-events:none，即使恢复权限也无法用指针编辑。Group没有公开stopDragging方法。这里不导入私有registry、不改私有DOM，也不合成mouseup来冒充真实释放。

仅在实际拖拽被撤权、收起、窄布局隐藏、pointercancel或窗口失焦中断时，以Vue key重建公开Group。比例、最近展开比例、折叠选择和非敏感备注由宿主持有；新Group使用当前比例，旧owner的layout/dragging/面板事件忽略。普通缩放、折叠与权限切换仍保留同一字段DOM，手势中断重建是明确例外。卸载移除观察器和窗口事件，旧异步焦点恢复检查owner/存活状态。

中断后等待实际mouseup/touchend/touchcancel，收到后在下一事件任务再结束注册，避免nextTick微任务抢先注销尚未执行的SDK释放监听；等待期只保留公开handle注册以让SDK接收真实释放，入口inert、ARIA不可用和宿主按键guard阻止新调整。此时提供始终可键盘到达的“恢复布局交互”：它解除本地等待，根据当前权限与可见性将焦点交给分隔条、展开按钮、标题或权限入口，不能绕过只读。键盘恢复不等于系统已经释放指针；若系统未交付真实松手，要再次拖动可先在恢复入口实际单击并松开。恢复入口发生过中断后保留，不因恢复动作删除自身焦点入口。

pointercancel通过CDP触摸取消输入产生浏览器isTrusted事件，随后使用真实键盘和鼠标继续操作，没有dispatchEvent伪造浏览器恢复结果。当前headless页签切换未产生可信blur，窗口blur仅在unit公开事件模型验证，不算操作系统窗口失焦验收；实体触控笔/触屏和跨窗口行为仍待验。它是有限本地布局恢复，不推广为业务请求取消/回执规则。

## 主题、字体与动效

导航与分栏正文使用现有rem角色；默认16px只是换算参考，200%实测正文32px。布局减少动效沿用正式包prefers-reduced-motion规则；不通过反复动画表示状态。Masonry继续按真实测高、稳定ID与单列阅读处理，Mentions继续按有限ASCII边界和应用时可用性检查，不额外包装。

## 实际参考

Ant固定revision为[dc3a92dcf2fd4d707418c2288901ecc86f26f647](https://github.com/ant-design/ant-design/tree/dc3a92dcf2fd4d707418c2288901ecc86f26f647)，本轮实际阅读相关段落：components/menu/Menu.tsx、index.en-US.md、__tests__/index.test.tsx中禁用链接测试；components/splitter/Splitter.tsx事件/收起回调、__tests__/a11y.test.ts；components/masonry/hooks/usePositions.ts稳定顺序与高度分配。没有运行上游React测试。

实际采用审阅ADV4.2.6 es/menu/src/Menu.js、MenuItem.js和SubMenu.js的键盘/禁用路径；Reka2.11.0 src/Splitter/SplitterGroup.vue、SplitterPanel.vue、SplitterResizeHandle.vue、utils/registry.ts及两个useWindowSplitter*Behavior.ts的公开事件和清理路径。私有文件只用于核实限制，SFC未导入。检查仅DOM、键盘、指针、计算样式、类型/构建及独立tgz消费，无截图、视频或trace，不宣称完整读屏、IME或跨浏览器通过。
