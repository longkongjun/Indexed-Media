# 集合、导航与虚拟化采用说明

自有方案0.8.0继续直接采用Ant Design Vue4.2.6公开API，不复制Ant默认外观，也不把React Ant6.6.7的API照搬到Vue。字体使用既有Indexed rem角色，日期七列表与双栏集合在窄窗保留局部横向滚动，不强行缩小重要文字。

## 真正的虚拟化与额外依赖

Ant Design Vue4.2.6没有公开Listy。旧List分页、content-visibility以及内部vc-*不满足本例要验证的窗口化能力；因此只在预览与完整SFC中直接采用成熟headless虚拟化，不制造正式库Listy包装或假导出。

```sh
npm install @tanstack/vue-virtual@3.13.48
```

本UI包仍从实际tgz安装；复制ListyRecipe.vue时还要安装上述精确额外依赖。机器描述的additional_dependencies提供实际包名、版本、官方HTTPS文档；外部消费者脚本按声明正常安装，所有66份SFC都进入真实生产构建。

采用依据为[Vue公开适配器文档](https://tanstack.com/virtual/latest/docs/framework/vue/vue-virtual)、[Virtualizer公开API](https://tanstack.com/virtual/latest/docs/api/virtualizer)、[官方动态高度示例](https://tanstack.com/virtual/latest/docs/framework/vue/examples/dynamic)。固定发布来源为[vue-virtual3.13.48官方npm tarball](https://registry.npmjs.org/@tanstack/vue-virtual/-/vue-virtual-3.13.48.tgz)，其公开依赖固定virtual-core3.19.7。已读采用包src/index.ts及core3.19.7 src/index.ts的ResizeObserver、measureElement、measure和scrollToIndex实现；宿主代码只调用公开接口。两包MIT原始许可保留在依赖分发中。

1000条数据保存在宿主，DOM只挂载窗口和overscan；稳定getItemKey来自业务ID，绝不以当前数组下标作稳定key。动态高度来自实际元素测量，初始estimateSize只是估值，跳转后继续修正。滚动卸载焦点行和移除所选项时交给稳定列表入口；刷新busy即时互斥且保名称/焦点，局部失败保留旧内容与选择，显式重试不重建列表。这里没有网络、无限加载、分组/吸顶、跨会话位置持久化，不能据此声称Ant Listy全API完成或海量读屏体验已验收。

## 成熟能力与宿主责任

Carousel不自动播放，公开goTo使用无动画模式，内容自然增高。边界使当前按钮不可用时转到反向入口。FloatButton限制在本地容器，实际产品固定位置与安全区需宿主定义。Affix等target容器就绪再挂载，位置测量是上游公开能力；transform祖先/嵌套滚动不作完整保证。

QRCode仅编码非凭据合成文本，文字payload保持可读；SVG为重复信息而隐藏于读屏树。局部失效移除图形并回到再生入口，未撤销任何真实服务端标记，也没有登录流程或相机扫描率结论。

Transfer使用公开children自定义列表槽，通过有标签的原生搜索/多选框改善采用版本默认内部checkbox缺少可访问名称的边界；移动、目标集合及选中回调仍采用成熟机制。完成后转交目标栏搜索。原生搜索空态能显式清除，权限项保留原生disabled，不等于服务端授权。

Calendar采用valueFormat日期字符串，不创建日程、不自动转换UTC。Mentions字段失败保留非敏感备注并focus真实textarea，键盘建议和局部popup保留；Vue4.2.6 options.disabled在方向键/Enter路径不会可靠跳过，本例宿主预先过滤不可用候选，并明确说明原因；确认只是本地演示，不会通知其他人。复杂IME、读屏、触控和实体设备体验仍需专项验收。

## 固定Ant源码参照

固定revision为[dc3a92dcf2fd4d707418c2288901ecc86f26f647](https://github.com/ant-design/ant-design/tree/dc3a92dcf2fd4d707418c2288901ecc86f26f647)，实际阅读：

- components/listy/index.tsx、demo/virtual.tsx、__tests__/index.test.tsx：虚拟化开关、稳定rowKey、滚动定位与配置优先级。
- components/float-button/FloatButton.tsx：原生入口、名称、按钮/链接与分组；Vue采用description，Ant6另有content及更晚的disabled API。
- components/carousel/index.tsx：显式goTo/afterChange，Ant6新增自动播放对象配置没有照搬。
- components/affix/index.tsx：指定滚动target与固定状态。
- components/qr-code/index.tsx：二维码值/图形/状态；components/qrcode/index.tsx只是旧别名，稳定目录ID为antd.qr-code。
- components/calendar/generateCalendar.tsx：日期选择与panel职责；Vue额外采用valueFormat字符串方式。
- components/transfer/index.tsx：目标集合与临时选择、公开自定义列表接口。
- components/mentions/index.tsx：建议、输入状态和原生输入职责。

同时核对八个组件目录index.en-US.md的官方API章节。仅阅读相关React测试，未运行上游测试。

实际Vue依据为安装包4.2.6的es/float-button/FloatButton.js、es/carousel/index.js及index.d.ts、es/affix/index.js、es/qrcode/index.js及interface.d.ts、es/calendar/generateCalendar.js及d.ts、es/transfer/index.js/list.js/ListItem.js/operation.js/search.js、es/mentions/index.js及index.d.ts；为定位键盘缺口额外阅读es/vc-mentions/src/Mentions.js和DropdownMenu.js，不从这些私有路径导入或调用；这些源码用于核对实际API与采用边界，不通过其私有接口调用组件。

## 验证边界

真实浏览器检查窗口挂载数量、远处定位、稳定key、刷新失败与焦点回退；字体放大检查实际计算字号和测量后的布局。没有采集截图、录像或trace，不据此宣称整套外观、相机扫码率、读屏、IME或所有复杂弹层的字体适配完成。
