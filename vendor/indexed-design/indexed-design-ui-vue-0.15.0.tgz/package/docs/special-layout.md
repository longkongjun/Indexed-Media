# 特殊布局、装饰与补充提示

自有方案0.13.0；正式组件依赖仍为Ant Design Vue4.2.6，未为了新增名称包装空壳或升级官方依赖。覆盖参照固定为Ant6.6.7，Masonry/Splitter/BorderBeam及非UI Util保留在目录。这里交付三份UI方案，不为Util制造页面控件。

## 精确额外依赖

```sh
npm install @egjs/grid@1.18.0 reka-ui@2.11.0
```

两包只用于相应完整SFC/预览，不是ui-vue的Masonry或Splitter导出。机器描述additional_dependencies提供精确版本和官方HTTPS资料；packed consumer按声明实际安装，全部71份SFC与体验页面都参与独立类型检查和生产构建。

Masonry采用[公开JS引擎](https://github.com/naver/egjs-grid)及[官方API入口](https://naver.github.io/egjs-grid/release/latest/doc/)，固定发布来自[grid1.18.0 tarball](https://registry.npmjs.org/@egjs/grid/-/grid-1.18.0.tgz)。已读安装包src/grids/MasonryGrid.ts的最短列排布、src/Grid.ts的尺寸观察/同步与destroy，以及公开declaration声明。曾评估官方Vue适配器，但其声明仍为旧实例接口，因此改用同一成熟引擎的公开JS接口，不增加类型断言桥接或调用私有方法。

Splitter采用[Reka官方指南](https://reka-ui.com/docs/components/splitter)，固定发布来自[reka-ui2.11.0 tarball](https://registry.npmjs.org/reka-ui/-/reka-ui-2.11.0.tgz)。已读安装包src/Splitter/SplitterGroup.vue、SplitterPanel.vue、SplitterResizeHandle.vue及utils/composables/useWindowSplitterBehavior.ts、useWindowSplitterPanelGroupBehavior.ts，核对方向键、Home/End、指针、最小比例、ARIA控制与数值。宿主只调用公开原语和props/events。

## 阅读、焦点和缩放

Masonry不是静态多列或图片摆放截图：引擎测量每项实际高度，按源顺序寻找最短列。Vue稳定key来自资料ID，CSS位置不会改变DOM/Tab顺序，不使用正tabindex补救视觉顺序。每项可展开真实长说明，文字高度变化触发重新测量，不用空白占位冒充高度分布。提供同一DOM的单列阅读切换，追加保持已存在节点与选择；移除选择后回到稳定追加入口。详情由当前稳定ID查询，而非持有过期对象；从详情移除该条会关闭弹层，afterClose优先回仍有效的原入口，入口删除则回追加入口或标题。权限锁定只禁止修改，查看详情、展开说明和单列阅读仍可用；追加/移除回调同样有权限guard。ResizeObserver同时观察容器与子项，Vue数据更新后公开syncElements，卸载destroy释放观察与事件。它不提供虚拟化、无限加载、分组或Ant6全部Masonry能力。

Splitter展开时主要面板25%至75%，折叠到0%，补充面板至少25%；分隔条名称、控制关系与当前数值均明确。成熟原语提供指针、方向键、Home/End；Home可收起。采用版本的组级Enter仅设置内部layout，不发同样的layout/面板回调，因此宿主在分隔条公开keydown.capture中preventDefault并调用公开collapse，保持收起状态和回调一致，宿主从公开layout事件记录最近展开比例，显式展开按钮调用公开expand/resize恢复该比例。采用版本的键盘/Home和指针折叠不会总是写入公开collapse()使用的内部缓存，故不依赖缓存一致性，不读取私有字段。Reka2.11收起后仍给aria-valuemin=25而now=0；本例不改私有DOM，而在收起时隐藏/禁用条并将条上焦点交给展开按钮，避免在辅助技术树中暴露越界分隔条。折叠时内容隐藏且inert，备注DOM与非敏感草稿保留；焦点若在将隐藏的内容中，回折叠入口或标题。窄容器或文字放大使可用宽度不足42rem时，原有面板DOM切为上下自然阅读；分隔条保留实例但隐藏/禁用且不进入Tab。如果切换前焦点在条上，宿主转交稳定标题；备注DOM不重建、非敏感内容保留。权限锁定同时禁用编辑、分隔条与折叠按钮，恢复不自动改比例/折叠选择。Reka2.11的handle.disabled只控制自身resize注册，独立的组级Enter折叠路径没有同样的disabled判断；宿主通过公开keydown.capture对锁定/上下阅读/收起时的Enter和调整键preventDefault，阻止组级处理，无私有DOM补丁。示例没有比例持久化或嵌套分割，不冒称完整Ant API。

Web字阶引用现有rem角色；根字号默认16px仅用于换算参考，200%不能锁成像素高度。原生项目按系统语义字体/缩放另行映射，不复制Web宽度或CSS装饰作为原生实现。

## 容器内的导航布局

Layout仍采用ADV4.2.6的Layout/Sider/Header/Content/Footer正式公开组件，宽侧栏使用12rem。ADV的breakpoint基于浏览器viewport固定px，不能表达嵌入容器或当前字体大小；本例由宿主ResizeObserver比较实际容器和42rem阈值，受控collapsed与width切换并排/上下布局。进入紧凑布局先收起，显式展开后导航在正文上方，不覆盖主要内容；Escape关闭并回入口。返回宽容器恢复此前宽布局的折叠选择，同一导航DOM和当前分区保持。隐藏导航inert/aria-hidden；从导航自动收起时将焦点移交有效入口。ADV has-sider给直接内容布局width:0用于并排flex分配；上下布局必须显式恢复内容宽度100%和自然flex，否则展开导航后正文宽度会归零。该覆盖限本例公开Layout样式，未修改采用库DOM或源码。没有真实路由、远端权限或SSR能力。

## 装饰不承担状态

BorderBeam直接使用原生CSS mask-composite、offset-path/offset-distance和媒体查询；[减少动效规范](https://drafts.csswg.org/mediaqueries-5/#prefers-reduced-motion)是系统约束。装饰aria-hidden、pointer-events:none，不抢占焦点；卡片静态边框、正文和按钮焦点描边独立。系统reduce或forced-colors停用装饰，本地暂停不能强行恢复系统禁用的动画。不支持相应CSS时保留静态边框，不宣称所有浏览器都显示动画。没有业务成功/忙碌/错误状态被编码在光效里。

Tooltip保留重要限制的可见正文，title只补充说明。受控open允许Escape显式关闭并留住入口焦点，关闭后不被同一次延迟触发重新打开；再次focus/hover可重新显示。aria-describedby把原生入口与正文/补充说明关联，局部getPopupContainer让主题/字号跟随宿主，长路径可换行。Tooltip内不放任务按钮或焦点陷阱；辅助技术/触控仍需专项验收。

## 固定Ant源码参照

固定revision为[dc3a92dcf2fd4d707418c2288901ecc86f26f647](https://github.com/ant-design/ant-design/tree/dc3a92dcf2fd4d707418c2288901ecc86f26f647)，实际阅读：

- components/masonry/index.tsx、Masonry.tsx、hooks/usePositions.ts、__tests__/index.test.tsx：动态测量、稳定key/顺序、最短列与测试组织。
- components/splitter/index.tsx、Splitter.tsx、SplitBar.tsx、__tests__/a11y.test.ts与__tests__/index.test.tsx中ARIA/缓存/键盘折叠相关段落：组合边界、拖动/数值语义与共享可访问性测试入口。
- components/border-beam/index.tsx、BorderBeam.tsx、BorderBeamEffect.tsx、style/index.ts、__tests__/index.test.tsx：独立装饰宿主、aria-hidden、遮罩/运动路径及减少动效降级。
- components/tooltip/index.tsx、__tests__/tooltip.test.tsx：受控打开、触发器与测试组织。

0.13另实际阅读components/layout/Sider.tsx、components/layout/__tests__/index.test.tsx的受控折叠/断点测试段落，以及components/layout/index.en-US.md。Masonry/Splitter继续核对上述实现/测试相关段落与各自index.en-US.md，安装包另读ADV es/layout/Sider.js与style/index.js的has-sider宽度规则、Reka SplitterPanel.vue/Group.vue/ResizeHandle.vue和两个useWindowSplitter*Behavior.ts的折叠/disabled路径；@egjs/grid实际读MasonryGrid.ts最短列与Grid.ts观察器/清理相关段落。

另核对以上四目录index.en-US.md的官方API章节。仅阅读相关React测试，未运行上游测试；实际Tooltip采用依据为Ant Design Vue4.2.6公开Tooltip/open/openChange/trigger/destroyTooltipOnHide/getPopupContainer与原生keydown/aria-describedby，不承诺Ant6新fresh/destroyOnHidden等API兼容。

## 验证边界

检查以真实DOM、键盘、指针、计算样式与构建为证据，不采集截图/录像/trace。布局与样式的自动检查不等于人工外观、完整读屏、触控设备、SSR或全浏览器认证。动态布局示例是有限数据，不替代Listy虚拟化；装饰不增加任何业务能力。

0.14.0新增在途拖拽中断的公开Group重建与键盘恢复，只有中断场景重建字段DOM，宿主仍持有草稿/比例/折叠状态；普通重排保持同DOM。详细生命周期与SDK限制见[导航与布局中断](navigation-and-interruptions.md)。
