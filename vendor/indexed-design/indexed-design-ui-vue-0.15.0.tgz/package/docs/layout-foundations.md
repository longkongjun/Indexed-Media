# 排版、布局与上下文的采用边界

自有方案版本0.7.0；实际运行 Ant Design Vue 4.2.6，直接导出成熟API，主题与rem语义排版由 Indexed 提供。Ant Design 6.6.7只作覆盖和实现思路参考。没有新增包装层、未升级官方依赖，也没有把两个平台的API当成相同版本。

## 可复制示例

完整代码来自预览运行的八份 `*Recipe.vue`，以JSON同源输出，包消费者需在宿主根部先设置 IndexedThemeProvider。入口是预览的 `#/component/typography`、divider、flex、grid、layout、space、anchor、app。

标题level负责语义结构，字号负责视觉角色；正文默认16px基准换算对应现有base token，分区标题lg、辅助说明sm，均通过rem解析，不能锁为px。Web放大200%依靠根字号；原生平台将同角色映射到平台可缩放文字，不把CSS类名或数值gutter照搬为原生字号。

## 核对的实际源码

Ant参考固定revision [`dc3a92dcf2fd4d707418c2288901ecc86f26f647`](https://github.com/ant-design/ant-design/tree/dc3a92dcf2fd4d707418c2288901ecc86f26f647)，仅阅读源码/官方文档，未运行其React测试：

- [Typography Title](https://github.com/ant-design/ant-design/blob/dc3a92dcf2fd4d707418c2288901ecc86f26f647/components/typography/Title.tsx)：level对应标题元素。
- [Divider](https://github.com/ant-design/ant-design/blob/dc3a92dcf2fd4d707418c2288901ecc86f26f647/components/divider/index.tsx)：Ant6方向/标题位置参数已分离，Vue采用版本不同。
- [Flex](https://github.com/ant-design/ant-design/blob/dc3a92dcf2fd4d707418c2288901ecc86f26f647/components/flex/index.tsx)、[Space](https://github.com/ant-design/ant-design/blob/dc3a92dcf2fd4d707418c2288901ecc86f26f647/components/space/index.tsx)：方向和gap演进不同，Vue示例使用实际支持的数值gap与direction。
- [Grid Row](https://github.com/ant-design/ant-design/blob/dc3a92dcf2fd4d707418c2288901ecc86f26f647/components/grid/row.tsx)、[Layout Sider](https://github.com/ant-design/ant-design/blob/dc3a92dcf2fd4d707418c2288901ecc86f26f647/components/layout/Sider.tsx)：真实视口断点，不能由预览容器冒充。
- [Anchor](https://github.com/ant-design/ant-design/blob/dc3a92dcf2fd4d707418c2288901ecc86f26f647/components/anchor/Anchor.tsx)、[AnchorLink](https://github.com/ant-design/ant-design/blob/dc3a92dcf2fd4d707418c2288901ecc86f26f647/components/anchor/AnchorLink.tsx)：链接/滚动/历史由宿主一并规划。
- [App context](https://github.com/ant-design/ant-design/blob/dc3a92dcf2fd4d707418c2288901ecc86f26f647/components/app/context.ts)：上下文实例从后代取得。

同时阅读以上八个目录的 `index.en-US.md` 官方API文档。实际Vue依据为安装包4.2.6的 `es/typography/index.js`、`es/divider/index.js`、`es/flex/index.js`、`es/grid/index.js`、`es/layout/Sider.js`、`es/space/index.js`、`es/anchor/Anchor.js`、`es/anchor/AnchorLink.js`、`es/app/index.js` 、`es/config-provider/hooks/useConfigInject.js`、`es/message/useMessage.js`、`es/_util/Portal.js` 与 `es/app/context.js`。官方Vue参考入口为[Ant Design Vue组件文档](https://www.antdv.com/components/overview/)。

## 交互与限制

Anchor4.2.6的click回调即使preventDefault仍会调用内部scrollTo。这里用宿主nav的原生捕获阶段接管已知页内链接，并stopPropagation；即时滚动、标题focus与hash所有权由同一处理器管理。没有对外部链接或上游全部模式作兼容承诺。

Layout隐藏的侧栏不可继续Tab进入；若断点变化隐藏当前焦点，转交展开按钮。按钮忙碌、权限禁用、字段错误和危险动作继续遵循[交互规则](interactions.md)，布局示例不发出业务请求。

App4.2.6的Holder经useConfigInject读取getContainer或ConfigProvider.getPopupContainer。容器函数在浮层初始化时会被调用；若此时ref未就绪而返回body，后续不会自动迁回局部DOM。本例等容器ref就绪再挂App，使用Provider公开getPopupContainer，并把App消息maxCount设为1，动态消息挂到局部主题DOM内，不用静态全局message。普通结果status，消息同key更新；子组件卸载只销毁自己的key，保留其他宿主实例。此方案未包括系统通知、SSR、多窗口及全部辅助技术验收。公开全量API仍以实际采用的4.2.6为准。

本轮App演示只验证message正文的rem字号在真实根200%时翻倍，以及局部品牌/明暗的计算颜色；内置图标/间距、notification/modal仍由上游数值token驱动，没有扩展为所有反馈弹层的字号或读屏保证。
