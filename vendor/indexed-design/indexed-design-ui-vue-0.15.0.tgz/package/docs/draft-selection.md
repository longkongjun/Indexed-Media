# 选择草稿与显式应用

0.12.0深化71份同源方案中的Mentions、Transfer、ColorPicker、Rate、Upload和Listy，不新增组件ID、包装或依赖。成熟实现仍按Ant Design Vue4.2.6的实际公开API采用，有限原生字段直接使用浏览器能力；正式导出的Upload/Rate等上游组件身份不变，recipe不是新包装导出。

## 提及与集合

Mentions的候选包含两个合成ASCII组，归档组从候选过滤，因为采用版本的键盘路径不会可靠跳过options.disabled。确认时再次核对手工输入的目标；只识别行首/空白后的@标识，不把邮箱片段当提及。可读目标列表同时给出组名与稳定ID，不用显示名称代替ID。草稿与已确认内容分开，错误保留原文并聚焦输入，撤销回确认内容。候选只是输入辅助，不代表真实成员授权；本例不发消息、不通知任何人，不是完整富文本/提及解析器或IME验收。

Transfer保留公开children/onItemSelect、targetKeys和selectedKeys机制，搜索与多选框直接使用原生字段。临时勾选、目标草稿与已确认集合分别持有；搜索空态提供清除，不自动代选。跨栏移动只修改草稿，应用空集合报错并回可选栏，取消恢复确认集合。全局权限与单项禁用同时在UI和宿主回调守卫中检查；只读时仍可搜索非敏感演示资料。放大后的双栏允许局部横向滚动，不压缩字号或假称已支持海量集合。

## 颜色与评分

颜色限定为不透明sRGB六位HEX。原生color入口之外提供有标签的文本字段、可读代码和显式应用/撤销；非法文本不会应用，色块保持上次确认颜色。只有确认才更新本地合成标记，不改品牌主题或服务。系统颜色面板由浏览器/OS绘制，文本路径用于可靠的键盘、校验与共享值；没有alpha、广色域、渐变或Ant6完整ColorPicker API。参考[HTML颜色字段](https://html.spec.whatwg.org/multipage/input.html#color-state-(type=color))。

ADV4.2.6的Star.js按value>index设置各星radio的aria-checked，会同时出现多个checked，不能把它视为正确的单选语义。本例使用disabled且aria-hidden的成熟Rate仅绘制装饰星形；有可见标签的原生select是唯一可访问评分入口，按半分选择并在正文给分数/总分。0在本例代表尚未评分，应用时报错，不自动当成已提交零分。草稿与确认评分分离，权限不可用和应用回调都有守卫；这是独立组合，不是修复或替换正式Rate库API。原生选择的系统面板行为随浏览器不同，真实Chromium检查采用typeahead输入和显式选择；没有承诺所有系统面板按键或读屏组合完成验收。

## 本地文件清单

Upload recipe只需要有限的本地清单，故直接使用原生file字段，不制造上传服务或进度。accept仅提示系统过滤，不能当作安全验证。本例限定.txt/.md、每项128KiB、最多3项，是演示策略；逐项说明拒绝原因并保留此前有效草稿。同名文件用独立递增ID区分，选择/移除只改草稿，取消系统选择不会清空已有清单，确认只保存本地元数据。没有读取内容、上传、保存文件、病毒检测或真实成功回执。真正的服务端校验、授权、网络回执和恢复由宿主实现。参考[HTML文件字段](https://html.spec.whatwg.org/multipage/input.html#file-upload-state-(type=file))。

## 虚拟列表中的选择

Listy继续直接采用公开@tanstack/vue-virtual@3.13.48，稳定ID、动态measureElement、窗口挂载与定位都保留。选择草稿与确认ID分离；应用/取消不会发业务请求。刷新入口保持名称与原生焦点、即时guard阻止重复，依赖编辑暂时disabled，旧列表和两层选择保留，失败后显式重试。权限锁定中断的仅是手动完成的本地模拟，不能据此推断真实在途请求已取消或清除未知回执；真实请求必须权威核对。移除当前项或滚动卸载焦点行后回稳定列表入口；移除已确认的合成条目会明确清除该本地确认ID。

这仍是平面动态高度虚拟列表子集，没有分组/吸顶/无限请求/服务端分页或Ant6全量Listy能力。[TanStack Vue Virtual公开文档](https://tanstack.com/virtual/latest/docs/framework/vue/vue-virtual)与安装包src/index.ts核对入口与卸载清理；SFC只调用公开API，不使用内部私有方法。

## 实际采用与验证边界

本轮实际核对安装的ADV4.2.6 es/mentions/index.js、es/vc-mentions/src/Mentions.js和DropdownMenu.js、es/transfer/index.js、es/rate/index.js和Star.js、es/upload/Upload.js与interface.d.ts；私有文件只用于核实限制，SFC不导入它们。色值、文件与评分原生字段不从ui-vue导入假造组件。

覆盖/交互组织参照为[Ant Design固定revision dc3a92dcf2fd4d707418c2288901ecc86f26f647](https://github.com/ant-design/ant-design/tree/dc3a92dcf2fd4d707418c2288901ecc86f26f647)。实际阅读相关API/禁用/回调/虚拟化段落：

- components/mentions/index.tsx、components/transfer/index.tsx、components/color-picker/ColorPicker.tsx
- components/rate/index.tsx、components/upload/Upload.tsx、components/listy/index.tsx
- components/mentions/__tests__/index.test.tsx、components/transfer/__tests__/customize.test.tsx、components/color-picker/__tests__/index.test.tsx
- components/rate/__tests__/index.test.tsx、components/upload/__tests__/upload.test.tsx、components/listy/__tests__/index.test.tsx
- 上述六组件index.en-US.md中相关API段落。

没有运行上游React测试，不复制Ant默认外观。正文、可读色值、评分、候选和集合标题使用便携rem/Indexed品牌规则；检查范围是定向unit、真实Chromium DOM/键盘/焦点/计算字号与正式tgz外部71份SFC消费。没有截图、录像或trace，也不宣称全读屏、全部IME、所有系统面板、真实上传服务或跨浏览器认证。
