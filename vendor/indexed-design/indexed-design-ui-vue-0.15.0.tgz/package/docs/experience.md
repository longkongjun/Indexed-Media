# Web 体验基础

0.3.0 在组件预览中提供独立 `#/experience` 路由。它不是 Ant 目录的一项，不增加组件覆盖分母。真实代码为 `apps/vue-preview/src/ExperienceFoundations.vue`，使用正式包公开入口、原生 HTML、已有 RequestState 与静态 Skeleton；没有新增一组业务页面包装组件，也不连接实际服务。

## 语义字阶

`indexedTypographyRoles` 导出七个固定角色及其已有 token 关联；`IndexedTypographyRole` 是对应 ID 类型。Provider 将共享源的字体 token 以 `--id-*` CSS 变量暴露，保留 rem，不把默认 16px 参考锁成所有用户的字号。正式样式提供 `id-type-{角色ID}`。

| 角色 | 字号 token | 行高 / 字重 | 用途 |
|---|---|---|---|
| display | font-size-display | tight / semibold | 仅概览展示 |
| overview | font-size-2xl | tight / semibold | 模块概览 |
| page-title | font-size-xl | tight / semibold | 当前页面与任务 |
| section-title | font-size-lg | tight / semibold | 页面分区 |
| body | font-size-base | normal / regular | 正文、字段与关键状态 |
| supporting | font-size-sm | relaxed / regular | 补充解释 |
| caption | font-size-xs | normal / regular | 非关键元信息 |

默认角色分别对应约 39、31、25、20、16、14、12px，数值只是 16px 根字号时的换算。错误、权限和恢复不能只使用 caption。根体验规范的 `foundations.typography.roles` 使用同一组 ID 和 token，页面展示不创建第二套字号。

体验页的 200% 开关用 `--id-text-scale` 放大字阶；按钮、字段、标题和内容自然换行，使用最小高度与内边距，避免固定高裁切。这是可交互的文字放大示例，仍需独立使用浏览器缩放、系统字号、读屏与实际设备验收，不能把开关通过当作全库无障碍认证。

## 状态与动作

| 状态 ID | 呈现与动作 |
|---|---|
| content | 正常内容与可编辑草稿，显式刷新 |
| loading | 首次加载，不展示旧内容；可访问加载说明与静态骨架 |
| refreshing | 保留内容和草稿，声明 busy；旧操作暂时 inert |
| empty-first-use | 说明尚无内容，创建第一条后进入可用内容并聚焦结果标题 |
| empty-search | 保留搜索上下文，清除筛选并聚焦搜索输入 |
| error | 保留草稿，说明失败，显式重试 |
| offline | 保留草稿，网络恢复后显式继续 |
| unauthenticated | 说明登录过期；本地模拟登录后继续原草稿 |
| forbidden | 说明所需权限、查看申请说明或返回，不反复重试 |
| not-found | 解释内容可能移动/删除，返回可用入口 |

401、403、404 是文案与语义映射，机器 ID 仍为 unauthenticated、forbidden、not-found。场景切换、重新登录和恢复不会清空本例的非敏感演示备注。这个策略不能外推为登录过期后仍无条件展示受保护内容、凭据或敏感输入；真实宿主按会话和权限策略隐藏、清理或恢复它们。示例只在页面内存持有非敏感备注，刷新或离开页面没有持久化保证；真实认证、授权、路由、数据与网络由宿主管理。

恢复由用户明确触发，完成本地演示后才回到内容，避免自动重试形成循环。创建后聚焦结果标题，清筛选后聚焦搜索框，恢复和重新登录后聚焦草稿；如果保留的搜索条件仍无匹配项，则回到 empty-search 并聚焦搜索框。被动场景切换和普通加载通知不抢走焦点。

## RequestState 的可伸展恢复槽

已有默认 Button 和 `retry` 事件保持兼容。0.3.0 增加可选的 `retry` 作用域槽，传入 `retry()`，便于宿主直接采用可伸展的原生操作，不为一个按钮再造包装组件：

```vue
<RequestState :state="{ kind: 'offline', stale: true }" @retry="recover">
  <template #retry="{ retry }">
    <button type="button" @click="retry">网络恢复后继续</button>
  </template>
  <Editor v-model="draft" />
</RequestState>
```

旧内容仍按既有契约应用 inert，视觉保留，暂时不接受交互。只有宿主更改 state 才能恢复正常内容；组件不执行网络或认证请求。

## ARIA、焦点与减少动效

- 加载容器使用 aria-busy，简短状态和常规认证/权限说明使用 status，突发请求失败使用 alert；骨架作为装饰不进入读屏树。
- 输入有可见 label；恢复按钮具有具体名称。权限说明的展开状态使用 aria-expanded/aria-controls。
- 200% 操作区采用原生表单与按钮，无固定文本高度；应用根部主题仍提供可见 focus-visible 样式。
- 体验骨架静态显示；包样式尊重 prefers-reduced-motion。浮层原语自身的焦点、键盘和系统差异继续使用成熟库能力并按实际平台检查。

## 深链接与嵌入协议

`components/vue/#/experience?state=error` 可直接进入状态。无效或缺失状态会在挂载时规范化为实际生效的 content hash。根工作台嵌入使用 `components/vue/?embed=experience#/experience?state=error`：这个专用模式不渲染组件侧栏或可离开体验的 wordmark，hash 改变也不卸载体验实例；独立应用仍可正常导航。

嵌入页面通过同源消息切换，整个 SFC 保持挂载，非敏感演示备注不重载：

```js
frame.contentWindow.postMessage({
  type: 'indexed-experience-state', state: 'offline'
}, location.origin);
```

只接受 `origin === location.origin` 且 `source === window.parent`、类型与状态都合法的消息。发生切换后，子页向父页回传 `{ type: 'indexed-experience-state-changed', state }`。父页同样需要核对 origin 和 iframe 的 contentWindow，不接受跨源或未知状态。顶层打开时不向自身回传，避免循环。

工程检查覆盖字阶映射、原生恢复槽、草稿保留、创建/清筛选/权限分流、合法消息与焦点目标；真实读屏朗读和全部设备外观仍独立记录。


## 0.4.0 的恢复与忙碌细节

刷新入口在 content / refreshing 之间保持同一个原生按钮；busy 时设置 aria-busy 与 aria-disabled、阻止重复动作，保留原焦点，不把加载直接等同于原生 disabled。错误/离线的显式恢复进入 refreshing 并聚焦这一入口；完成仍需使用独立的演示完成动作。进入新的状态会清除过时的成功播报。

恢复和模拟登录不会绕开保留的筛选条件：仍无匹配项时回到搜索空态，不呈现没有解释的空白内容。取消首次创建回到创建入口并保留已填名称；权限说明可通过按钮或 Escape 关闭并回到入口。它们均为本地交互，不表示真实服务已恢复。


## 0.5.0 的失效焦点处理

体验状态切换先保留当前有效焦点；如果原入口被移除或进入 inert 旧内容，而浏览器已落到 body 或仍停在失效入口，则聚焦可见、稳定的页面标题。主动完成、取消、清筛选等动作仍优先使用其具体目标，不把所有状态变化都变成抢焦点。

常用组件文字的实际缩放与体验页的诊断开关分开验证：公开样式让关键表格/字段/状态、按钮、标签、计数与统计引用已有 rem token；最小高度允许文字伸展。采用库默认 body 挂载的复杂弹层还依赖数值主题 token，不能把部分浏览器检查当作全组件无障碍或原生字号通过。


## 可操作的交互对照

0.6.0 的[交互实验](interactions.md)将七条规则组织为真实可操作的推荐/问题对照，覆盖忙碌与禁用、字段错误、焦点、反馈、重排、系统动效偏好和未知结果核对。它是预览场景，不增加组件目录或假造包导出。
