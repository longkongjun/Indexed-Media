# 日期、数值、引导与显示边界

0.11.0深化DatePicker、TimePicker、Calendar、Slider四份既有SFC，新增Tour、Watermark两份完整采用SFC，共71份，预览仍为73个稳定入口。没有新增正式组件包装或升级依赖。导出的Ant Design Vue4.2.6组件保留原身份；recipe采用原生字段或公开Modal组合时，会明确写出实际API，不冒称Ant6全能力。

## 日期与时间

日历日期以YYYY-MM-DD表达，钟面时间以HH:mm表达。二者都没有业务时区，也不是已解析的UTC时刻。示例不调用new Date(date)构造业务时间，不暗中绑定今日、系统时区或通知调度。真实预约必须由宿主补充业务日期、IANA时区与夏令时缺失/重复时刻规则，并由服务端验证。[HTML Date/Time字段标准](https://html.spec.whatwg.org/multipage/input.html#date-state-(type=date))说明字段值与系统显示的边界。

DatePicker和TimePicker保留独立可选成熟选择器，公开getPopupContainer挂本例region、公开focus在清除后回到仍有效入口。值使用valueFormat而不是依赖Dayjs内部对象。成熟选择器的选择仅改变参考值，不等于业务确认；严格关联字段错误的必选场景直接采用浏览器date/time输入，有可见标签、aria-invalid/aria-describedby、显式确认与撤销。Date演示范围固定为2026年，Time演示五分钟步长；这些只是本例策略，不是全项目默认规则。宿主同时检查范围和步长，不能只信任min/max/step或客户端disabled。

Calendar七列成熟网格与原生键盘日期输入共用草稿。选择只修改草稿，确认才更新本地确认值；撤销回上次确认值，空值报错保留确认。权限演示将字段disabled、七列区域inert，恢复保留非敏感草稿。4.2.6网格的完整键盘/读屏行为没有因为加了原生入口就被修复；不要把它标成全量无障碍日历。年/月选择可能影响成熟日历值，仍须显式确认。

本轮作用域CSS使成熟日期输入、日期格和时间行采用rem；时间行可随文字自然增高，七列内容保留局部滚动，控件字号不因窄窗被压小。系统原生面板由浏览器/OS绘制，CSS不承诺接管系统面板皮肤。日期区间、时区换算、大量禁用日期、复杂滚动祖先和完整辅助技术验收均另行处理。

## 有限数值范围

0–100、步长5的清晰度场景用原生range和number足够，无需依赖4.2.6顶层类型未声明的手柄ARIA扩展。[HTML Range标准](https://html.spec.whatwg.org/multipage/input.html#range-state-(type=range))和浏览器处理键盘/拖动；本例使用显式label与描述，不改私有DOM。原生拖块外观允许随浏览器不同，主题只配置accent-color、字体与必要点击区域。

数字草稿保存为字符串，空值保持未填写。确认检查有限数值、0–100范围与5步长；空值、越界、非步长值不会夹断为成功。无效数字草稿时range保留上次确认值，文字明确说明。取消恢复确认值；权限不可用使用disabled，与请求busy分别表达。本例没有图片处理、上传、网络保存或多手柄范围算法。

## 可跳过引导

4.2.6 Tour没有与Ant6相同的公开keyboard/getPopupContainer契约，默认面板关闭图标也不是完整可聚焦关闭按钮。本例直接采用已交付公开Modal组织两步任务说明，重用成熟焦点陷阱、Escape、ARIA标题和局部主题容器，不访问vc-tour私有接口。它不是锚定遮罩、目标追踪、滚动定位或跨页Tour实现。

引导只由明确操作启动，允许跳过、上一步、下一步和完成。下一步不隐式提交任务；关闭/完成保留非敏感备注，当前步骤变化聚焦步骤标题，最终回有效入口，入口移除则回稳定页面标题。权限、业务保存和真实完成结果由宿主负责，不由引导完成代替。

## 装饰水印

成熟Watermark绘制合成署名，装饰层aria-hidden、pointer-events:none；正文保留同等可读署名与限制，正文按钮和焦点独立。署名草稿经显式应用才更新，空值/超长显示字段错误，撤销回上次应用值。font.fontSize接受数值px，本例从局部实际计算字号转换，不将rem字符串交给采用库Number(fontSize)；观察根字号与局部容器，卸载清理ResizeObserver/MutationObserver。

水印可以隐藏或移除，不能防复制、防截图，也不是身份验证、访问控制、审计或安全保证。不放入真实凭据/用户标识；示例只有非敏感合成内容，真实鉴权/审计/导出策略属于宿主服务。Canvas图形不替代正文语义，不对所有浏览器截图/打印结果作保证。

## 实际来源

运行采用ant-design-vue@4.2.6。本轮核对安装包es/date-picker/generatePicker/generateSinglePicker.js的valueFormat/事件/focus/getPopupContainer，es/calendar/generateCalendar.js的update:value与select，es/tour/index.js、es/tour/interface.d.ts、es/tour/panelRender.js及es/vc-tour/Tour.js的公开契约边界，es/watermark/index.js的Canvas数值字号与绘制/清理结构。私有文件只用于核实限制，SFC不导入它们。

覆盖/交互参照为[Ant Design固定revision dc3a92dcf2fd4d707418c2288901ecc86f26f647](https://github.com/ant-design/ant-design/tree/dc3a92dcf2fd4d707418c2288901ecc86f26f647)，实际阅读相关API/焦点/禁用/事件/字号与测试组织段落：

- components/date-picker/generatePicker/generateSinglePicker.tsx、components/time-picker/index.tsx、components/calendar/generateCalendar.tsx
- components/slider/index.tsx、components/tour/index.tsx、components/watermark/index.tsx
- components/date-picker/__tests__/DatePicker.test.tsx、components/time-picker/__tests__/index.test.tsx、components/calendar/__tests__/select.test.tsx
- components/slider/__tests__/index.test.tsx、components/tour/__tests__/index.test.tsx、components/watermark/__tests__/index.test.tsx
- 上述六项目录的index.en-US.md中相关API段落。

Ant6的needConfirm、Tour keyboard/getPopupContainer等新契约不能假定存在于Vue4.2.6。本轮没有运行React测试，不复制Ant默认外观。类型/构建、宿主状态unit、真实Chromium DOM/键盘/计算字号和正式tgz外部71份SFC消费者验证各自记录；不采截图、录像或trace，不代表读屏、全部IME/触屏/浏览器或人工外观已验收。
