package dev.indexed.design.tv

import android.content.res.ColorStateList
import android.view.View
import android.widget.ProgressBar
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.graphics.toArgb
import androidx.compose.foundation.layout.size

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.Border
import androidx.tv.material3.ColorScheme
import androidx.tv.material3.Button
import androidx.tv.material3.ButtonDefaults
import androidx.tv.material3.Card
import androidx.tv.material3.CardDefaults
import androidx.tv.material3.LocalContentColor
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.Text
import androidx.tv.material3.Typography
import androidx.tv.material3.Shapes
import androidx.tv.material3.darkColorScheme
import androidx.tv.material3.lightColorScheme

private val LocalFocusColor = staticCompositionLocalOf { Color(0xFF5CD39A) }

// Default evergreen semantic palette; override the public theme colorScheme for another brand.
private val Light =
    lightColorScheme(
        primary = Color(0xFF08744B),
        onPrimary = Color(0xFFFFFFFF),
        background = Color(0xFFF4F7F5),
        onBackground = Color(0xFF12231C),
        surface = Color(0xFFFFFFFF),
        onSurface = Color(0xFF12231C),
        onSurfaceVariant = Color(0xFF50655C),
        primaryContainer = Color(0xFFE8F5EE),
        onPrimaryContainer = Color(0xFF12231C),
        secondary = Color(0xFF08744B),
        onSecondary = Color(0xFFFFFFFF),
        secondaryContainer = Color(0xFFE8F5EE),
        onSecondaryContainer = Color(0xFF12231C),
        surfaceVariant = Color(0xFFEDF4F0),
        border = Color(0xFFB9C9C1),
        borderVariant = Color(0xFFDCE7E1),
        error = Color(0xFF8B2A2A),
        onError = Color(0xFFFFFFFF),
        errorContainer = Color(0xFFFFF7F7),
        onErrorContainer = Color(0xFF8B2A2A),
    )

private val Dark =
    darkColorScheme(
        primary = Color(0xFF4CC38A),
        onPrimary = Color(0xFF0A1410),
        background = Color(0xFF0C1310),
        onBackground = Color(0xFFE6EDE8),
        surface = Color(0xFF121B16),
        onSurface = Color(0xFFE6EDE8),
        onSurfaceVariant = Color(0xFF9FB3A7),
        primaryContainer = Color(0xFF16302A),
        onPrimaryContainer = Color(0xFFE6EDE8),
        secondary = Color(0xFF4CC38A),
        onSecondary = Color(0xFF0A1410),
        secondaryContainer = Color(0xFF16302A),
        onSecondaryContainer = Color(0xFFE6EDE8),
        surfaceVariant = Color(0xFF080D0A),
        border = Color(0xFF2A3A32),
        borderVariant = Color(0xFF1D2A23),
        error = Color(0xFFE57373),
        onError = Color(0xFF200A0A),
        errorContainer = Color(0xFF3A1A1A),
        onErrorContainer = Color(0xFFE57373),
    )

/** Default TV palette. Does not share mobile MaterialTheme at runtime. */
fun indexedTvColorScheme(dark: Boolean): ColorScheme = if (dark) Dark else Light

fun indexedTvShapes(): Shapes = Shapes(
    extraSmall = RoundedCornerShape(4.dp),
    small = RoundedCornerShape(8.dp),
    medium = RoundedCornerShape(12.dp),
    large = RoundedCornerShape(20.dp),
    extraLarge = RoundedCornerShape(28.dp),
)

object IndexedTvSpacing {
    val inline = 12.dp
    val group = 16.dp
    val content = 24.dp
    val pageHorizontal = 48.dp
    val pageVertical = 27.dp
}

/** Brand entry point. Focus uses a separate semantic color from selection. */
@Composable
fun IndexedTvTheme(
    dark: Boolean = true,
    colorScheme: ColorScheme = indexedTvColorScheme(dark),
    typography: Typography = indexedTvTypography(),
    shapes: Shapes = indexedTvShapes(),
    focusColor: Color = if (dark) Color(0xFF5CD39A) else Color(0xFF0B7A50),
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = colorScheme,
        typography = typography,
        shapes = shapes,
        content = {
            CompositionLocalProvider(
                LocalContentColor provides MaterialTheme.colorScheme.onBackground,
                LocalFocusColor provides focusColor,
            ) { content() }
        },
    )
}

/** Typography sized for the 960 x 540 dp TV design canvas, while respecting font scale. */
fun indexedTvTypography(): Typography = Typography(
    displayLarge = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 39.sp, lineHeight = 49.sp),
    displayMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 39.sp, lineHeight = 49.sp),
    displaySmall = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 31.sp, lineHeight = 40.sp),
    bodyLarge = TextStyle(fontWeight = FontWeight.Normal, fontSize = 20.sp, lineHeight = 30.sp),
    bodyMedium = TextStyle(fontWeight = FontWeight.Normal, fontSize = 20.sp, lineHeight = 30.sp),
    bodySmall = TextStyle(fontWeight = FontWeight.Normal, fontSize = 20.sp, lineHeight = 30.sp),
    labelMedium = TextStyle(fontWeight = FontWeight.Medium, fontSize = 20.sp, lineHeight = 30.sp),
    labelSmall = TextStyle(fontWeight = FontWeight.Medium, fontSize = 20.sp, lineHeight = 30.sp),
    titleMedium = TextStyle(fontWeight = FontWeight.Medium, fontSize = 20.sp, lineHeight = 30.sp),
    titleSmall = TextStyle(fontWeight = FontWeight.Medium, fontSize = 20.sp, lineHeight = 30.sp),
    headlineSmall = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 25.sp, lineHeight = 32.sp),
    labelLarge = TextStyle(fontWeight = FontWeight.Medium, fontSize = 20.sp, lineHeight = 30.sp),
    titleLarge = TextStyle(fontWeight = FontWeight.Medium, fontSize = 20.sp, lineHeight = 30.sp),
    headlineLarge = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 39.sp, lineHeight = 49.sp),
    headlineMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 31.sp, lineHeight = 40.sp),
)

/** 受控Action；busy保留标签并阻止重复事件，结果和请求生命周期由宿主持有。 */
@Composable
fun IndexedTvButton(
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    busy: Boolean = false,
    busyDescription: String = "正在处理",
) {
    Button(
        onClick = { if (enabled && !busy) onClick() },
        modifier =
            modifier
                .defaultMinSize(minWidth = 48.dp, minHeight = 48.dp)
                .semantics { if (busy) stateDescription = busyDescription },
        enabled = enabled,
        scale = ButtonDefaults.scale(focusedScale = 1f),
        border =
            ButtonDefaults.border(
                border = Border.None,
                focusedBorder = indexedTvFocusBorder(),
                pressedBorder = indexedTvFocusBorder(),
                focusedDisabledBorder = indexedTvFocusBorder(),
            ),
        colors =
            ButtonDefaults.colors(
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                focusedContainerColor = MaterialTheme.colorScheme.primary,
                focusedContentColor = MaterialTheme.colorScheme.onPrimary,
            ),
    ) {
        val indicatorTint = LocalContentColor.current.toArgb()
        if (busy) {
            // Official platform widget: no phone MaterialTheme or custom animation engine on TV.
            AndroidView(factory = { context ->
                ProgressBar(context, null, android.R.attr.progressBarStyleSmall).apply {
                    isIndeterminate = true
                    isFocusable = false
                    isClickable = false
                    importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
                }
            }, update = { it.indeterminateTintList = ColorStateList.valueOf(indicatorTint) },
                modifier = Modifier.padding(end = 8.dp).size(16.dp).clearAndSetSemantics {})
        }
        Text(label)
    }
}

/** 通用内容卡；标题/副文是普通值，图片槽由宿主加载且不重复朗读标题。 */
@Composable
fun IndexedTvContentCard(
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    artwork: @Composable () -> Unit = {},
) {
    Card(
        onClick = onClick,
        modifier =
            modifier
                .defaultMinSize(minHeight = 48.dp),
        scale = CardDefaults.scale(focusedScale = 1f),
        border = CardDefaults.border(focusedBorder = indexedTvFocusBorder(), pressedBorder = indexedTvFocusBorder()),
        colors =
            CardDefaults.colors(
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.onSurface,
                focusedContainerColor = MaterialTheme.colorScheme.surface,
                focusedContentColor = MaterialTheme.colorScheme.onSurface,
            ),
    ) {
        Column(
            Modifier.padding(IndexedTvSpacing.group),
            verticalArrangement = Arrangement.spacedBy(IndexedTvSpacing.inline),
        ) {
            Box(Modifier.clearAndSetSemantics {}) { artwork() }
            Column {
                Text(title, style = MaterialTheme.typography.titleLarge, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(subtitle, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

/** Poster-first TV card. The host owns image loading, stable media identity and grid focus. */
@Composable
fun IndexedTvPosterCard(
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    artwork: @Composable () -> Unit = {},
) {
    Card(
        onClick = onClick,
        modifier = modifier,
        scale = CardDefaults.scale(focusedScale = 1f),
        border = CardDefaults.border(focusedBorder = indexedTvFocusBorder(), pressedBorder = indexedTvFocusBorder()),
        colors = CardDefaults.colors(
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = MaterialTheme.colorScheme.onSurface,
            focusedContainerColor = MaterialTheme.colorScheme.surface,
            focusedContentColor = MaterialTheme.colorScheme.onSurface,
        ),
    ) {
        Column(Modifier.fillMaxWidth()) {
            Box(Modifier.fillMaxWidth().aspectRatio(2f / 3f).clearAndSetSemantics {}) { artwork() }
            Column(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp)) {
                Text(title, style = MaterialTheme.typography.titleLarge, minLines = 2, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(subtitle, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

/** 恢复提示组合；状态、文案与重试策略由宿主决定，不推导业务结果。 */
@Composable
fun IndexedTvMessage(
    message: String,
    modifier: Modifier = Modifier,
    action: @Composable ColumnScope.() -> Unit = {},
) = IndexedTvMessage(message, modifier, false, action)

@Composable
fun IndexedTvMessage(
    message: String,
    modifier: Modifier = Modifier,
    isError: Boolean,
    action: @Composable ColumnScope.() -> Unit = {},
) {
    Column(modifier.padding(IndexedTvSpacing.group), verticalArrangement = Arrangement.spacedBy(IndexedTvSpacing.inline)) {
        Text(message, style = MaterialTheme.typography.bodyLarge, color = if (isError) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface)
        action()
    }
}

/** 语义焦点色读取；宿主手绘焦点描边必须读它，与选中色(primary)分离并跟随品牌 focusColor。 */
@Composable
fun indexedTvFocusColor(): Color = LocalFocusColor.current

// 4dp外移留出画布间隔，主操作同色实心背景仍有可辨识焦点边界。
@Composable
fun indexedTvFocusBorder(): Border =
    Border(
        border = BorderStroke(3.dp, indexedTvFocusColor()),
        inset = 4.dp,
        shape = MaterialTheme.shapes.medium,
    )
