package dev.indexed.design.android

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight

// Default evergreen semantic palette; override the public theme colorScheme for another brand.
private val Light =
    lightColorScheme(
        primary = Color(0xFF08744B),
        onPrimary = Color(0xFFFFFFFF),
        background = Color(0xFFF4F7F5),
        onBackground = Color(0xFF12231C),
        surface = Color(0xFFFFFFFF),
        onSurface = Color(0xFF12231C),
        onSurfaceVariant = Color(0xFF50655C),
        primaryContainer = Color(0xFFE8F5EE),
        onPrimaryContainer = Color(0xFF12231C),
        secondary = Color(0xFF08744B),
        onSecondary = Color(0xFFFFFFFF),
        secondaryContainer = Color(0xFFE8F5EE),
        onSecondaryContainer = Color(0xFF12231C),
        surfaceVariant = Color(0xFFEDF4F0),
        outline = Color(0xFFB9C9C1),
        outlineVariant = Color(0xFFDCE7E1),
        error = Color(0xFF8B2A2A),
        onError = Color(0xFFFFFFFF),
        errorContainer = Color(0xFFFFF7F7),
        onErrorContainer = Color(0xFF8B2A2A),
        surfaceContainerLowest = Color(0xFFFFFFFF),
        surfaceContainerLow = Color(0xFFF4F7F5),
        surfaceContainer = Color(0xFFEDF4F0),
        surfaceContainerHigh = Color(0xFFFFFFFF),
        surfaceContainerHighest = Color(0xFFEDF4F0),
    )

private val Dark =
    darkColorScheme(
        primary = Color(0xFF4CC38A),
        onPrimary = Color(0xFF0A1410),
        background = Color(0xFF0C1310),
        onBackground = Color(0xFFE6EDE8),
        surface = Color(0xFF121B16),
        onSurface = Color(0xFFE6EDE8),
        onSurfaceVariant = Color(0xFF9FB3A7),
        primaryContainer = Color(0xFF16302A),
        onPrimaryContainer = Color(0xFFE6EDE8),
        secondary = Color(0xFF4CC38A),
        onSecondary = Color(0xFF0A1410),
        secondaryContainer = Color(0xFF16302A),
        onSecondaryContainer = Color(0xFFE6EDE8),
        surfaceVariant = Color(0xFF080D0A),
        outline = Color(0xFF2A3A32),
        outlineVariant = Color(0xFF1D2A23),
        error = Color(0xFFE57373),
        onError = Color(0xFF200A0A),
        errorContainer = Color(0xFF3A1A1A),
        onErrorContainer = Color(0xFFE57373),
        surfaceContainerLowest = Color(0xFF080D0A),
        surfaceContainerLow = Color(0xFF121B16),
        surfaceContainer = Color(0xFF17221C),
        surfaceContainerHigh = Color(0xFF17221C),
        surfaceContainerHighest = Color(0xFF080D0A),
    )

/** Default complete Material palette; callers can copy any semantic role for a brand. */
fun indexedColorScheme(dark: Boolean): ColorScheme = if (dark) Dark else Light

/** Brand defaults configure official Material shapes rather than drawing replacement controls. */
fun indexedShapes(): Shapes = Shapes(
    extraSmall = RoundedCornerShape(4.dp),
    small = RoundedCornerShape(8.dp),
    medium = RoundedCornerShape(12.dp),
    large = RoundedCornerShape(20.dp),
    extraLarge = RoundedCornerShape(28.dp),
)

object IndexedSpacing {
    val inline = 8.dp
    val content = 12.dp
    val group = 16.dp
    val page = 24.dp
}

/** Maps existing semantic.font.size tiers (39/31/25/20/16/14/12), in scalable native sp. */
fun indexedTypography(): Typography = Typography(
    displayLarge = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 39.sp, lineHeight = 49.sp),
    displayMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 39.sp, lineHeight = 49.sp),
    displaySmall = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 31.sp, lineHeight = 40.sp),
    headlineLarge = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 39.sp, lineHeight = 49.sp),
    headlineMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 31.sp, lineHeight = 40.sp),
    headlineSmall = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 25.sp, lineHeight = 32.sp),
    titleLarge = TextStyle(fontWeight = FontWeight.Medium, fontSize = 20.sp, lineHeight = 30.sp),
    titleMedium = TextStyle(fontWeight = FontWeight.Medium, fontSize = 20.sp, lineHeight = 30.sp),
    titleSmall = TextStyle(fontWeight = FontWeight.Medium, fontSize = 16.sp, lineHeight = 24.sp),
    bodyLarge = TextStyle(fontWeight = FontWeight.Normal, fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontWeight = FontWeight.Normal, fontSize = 14.sp, lineHeight = 21.sp),
    bodySmall = TextStyle(fontWeight = FontWeight.Normal, fontSize = 12.sp, lineHeight = 18.sp),
    labelLarge = TextStyle(fontWeight = FontWeight.Medium, fontSize = 14.sp, lineHeight = 21.sp),
    labelMedium = TextStyle(fontWeight = FontWeight.Medium, fontSize = 12.sp, lineHeight = 18.sp),
    labelSmall = TextStyle(fontWeight = FontWeight.Medium, fontSize = 12.sp, lineHeight = 18.sp),
)

/** Brand entry point. Host owns theme preference; official Material components inherit it. */
@Composable
fun IndexedTheme(
    dark: Boolean = isSystemInDarkTheme(),
    colorScheme: ColorScheme = indexedColorScheme(dark),
    typography: Typography = indexedTypography(),
    shapes: Shapes = indexedShapes(),
    content: @Composable () -> Unit,
) {
    MaterialTheme(colorScheme = colorScheme, typography = typography, shapes = shapes) {
        CompositionLocalProvider(LocalContentColor provides MaterialTheme.colorScheme.onBackground) { content() }
    }
}

/** 受控Action；busy保留标签并阻止重复事件，结果和请求生命周期由宿主持有。 */
@Composable
fun IndexedButton(
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    busy: Boolean = false,
    busyDescription: String = "正在处理",
) {
    Button(
        onClick = { if (enabled && !busy) onClick() },
        modifier =
            modifier
                .defaultMinSize(minWidth = 48.dp, minHeight = 48.dp)
                .semantics { if (busy) stateDescription = busyDescription },
        enabled = enabled,
    ) {
        if (busy) {
            CircularProgressIndicator(Modifier.padding(end = IndexedSpacing.inline).size(16.dp), color = LocalContentColor.current, strokeWidth = 2.dp)
        }
        Text(label)
    }
}

/** 通用内容卡；标题/副文是普通值，图片槽由宿主加载且不重复朗读标题。 */
@Composable
fun IndexedContentCard(
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    artwork: @Composable () -> Unit = {},
) {
    Card(
        onClick = onClick,
        modifier = modifier.defaultMinSize(minHeight = 48.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    ) {
        Row(
            Modifier.padding(IndexedSpacing.group),
            horizontalArrangement = Arrangement.spacedBy(IndexedSpacing.content),
        ) {
            Box(Modifier.clearAndSetSemantics {}) { artwork() }
            Column {
                Text(title, style = MaterialTheme.typography.titleMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

/** 恢复提示组合；状态、文案与重试策略由宿主决定，不推导业务结果。 */
@Composable
fun IndexedMessage(
    message: String,
    modifier: Modifier = Modifier,
    action: @Composable ColumnScope.() -> Unit = {},
) {
    Column(modifier.padding(IndexedSpacing.group), verticalArrangement = Arrangement.spacedBy(IndexedSpacing.content)) {
        Text(message, style = MaterialTheme.typography.bodyLarge)
        action()
    }
}
